# Flux Stream

A personal Kodi add-on foundation based on [Jacktook](https://github.com/Sam-Max/plugin.video.jacktook) by Sam-Max.

The supported configuration is TorBox for playback, CocoScrapers for discovery, Trakt for tracking, and TMDB for metadata and artwork. IMDb IDs remain part of title matching. TorBox authorization and cached playback have been confirmed on the owner's Kodi device; Trakt QR authorization still needs live confirmation.

## Identity and isolation

- Display name: Flux Stream
- Add-on ID: `plugin.video.personalstream`
- Version: `0.3.9`
- Kodi-managed profile: `special://profile/addon_data/plugin.video.personalstream/`
- Private session properties use the `personalstream` namespace.
- The upstream updater, installation helper, automatic TMDBHelper writes, donation prompt, and unrelated background services have been removed from the active flow.
- No existing Jacktook account settings or databases are migrated or modified.

## Setup

1. Use Kodi 21 as the initial development target. Other versions and playback hardware still need validation.
2. Install and enable `script.module.cocoscrapers` separately from its developer's repository. This build does not install third-party repositories automatically.
3. Install the Flux Stream ZIP using Kodi's Install from zip file action.
4. Under Settings > Accounts, authorize TorBox.
5. TMDB metadata is included through Flux Stream's registered application key. No TMDB account or key entry is needed. An optional personal key override remains available at Expert level under Metadata.
6. For Trakt, choose Accounts > Connect Trakt (QR code), scan the displayed QR code, enter the short activation code if prompted, and approve Flux Stream. Its public development-app Client ID is bundled; a client secret is not required. Tracking enables after successful authorization and background sync waits for the initial connection. Optional developer overrides are available only at Expert settings level.

Sources are cached-only. Manual source selection is the default. Retired integrations are disabled by runtime settings even if an imported profile contains old flags. Their code remains where shared imports still require it; this is a narrowed foundation, not a completed removal of every unused module.

Continue Watching separates local progress and Trakt progress. Combining those feeds and reconciling offline conflicts is later work. Scraper searches have a configurable 20-second default deadline. Timeout returns completed sources without caching the incomplete search. Cancel stops the flow before filtering, cache checks, or playback. At most eight daemon provider workers may be outstanding in one interpreter; queued work stops on timeout/cancel and late results are discarded. Python cannot forcibly interrupt a blocked third-party network call, so a busy worker may remain until its provider returns. Both legacy search presentation settings use the same native cancelable progress dialog.

## Local Windows development

From this checkout in PowerShell, use an isolated environment:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-test.txt
.\.venv\Scripts\python.exe -m pytest tests/unit/test_personalstream_foundation.py tests/unit/test_settings_xml.py tests/unit/test_updater.py
.\.venv\Scripts\python.exe package.py
```

The package is written to `dist/plugin.video.personalstream-0.3.9.zip`. Use `python package.py --output <directory>` to choose another destination. Tests, development configuration, caches, the original player-helper ZIP, and repository metadata are excluded. The ZIP contains the required `plugin.video.personalstream/` top-level folder.

The larger upstream suite has test isolation/mock failures in a combined Windows run, observed before this fork changed the code. Run relevant integration groups separately and distinguish these baseline failures from regressions.

## Attribution and licensing

Original Jacktook source snapshot: `cb3bd2d2dc08dd35a98aabc668f319e31137fff9`.

Original copyright notices and the upstream LICENSE are retained. Upstream LICENSE contains GPL version 3, while addon.xml declares GPL-2.0-only. This discrepancy is unresolved; clarify it before distributing a derivative. Flux Stream icon, fanart, and clearlogo use original retro-futurist artwork; remaining interface glyphs retain upstream attribution.

TMDB attribution: This product uses the TMDB API but is not endorsed or certified by TMDB. Settings > Metadata > About / Credits displays the included TMDB logo and required notice.

Validate Trakt account authorization, CocoScrapers compatibility, movie and episode playback, seeking/resume, and Trakt progress on the target device before treating the build as ready for use.


## Search controls and filters

Movies and individual TV episodes retain their Rescrape and Source Select context-menu actions. Rescrape bypasses cached search results and the quick-play shortcut. Source Select forces the manual chooser even when autoplay is enabled.

Settings > Sources controls the scraper deadline, from 5 to 120 seconds. Cancel stops the search; a timeout can still show sources completed before the deadline. A timeout does not write partial results as a complete cached search.

Settings > Filtering includes minimum/maximum reported release sizes in MiB, literal case-insensitive name filters, allowed containers, codec preferences, and HDR preferences. Required name terms are comma-separated and all must occur; any excluded term removes a release. Blank fields disable those filters. Unknown source sizes are retained. Season-pack sizes are reported release sizes, not per-episode sizes.

Allowed containers can be entered as `mkv, mp4` or `.mkv, .mp4`. A release with no identifiable container can remain in the source list; the actual TorBox filename is checked before generating a playback link, including cloud and pack playback. File-type filtering does not change the underlying codec.

Settings > Home menu lets you hide optional sections, choose Continue Watching/Movies/TV Shows as the first visible section, and open Kodi's existing section-view chooser. Settings remains available even when every optional section is hidden. View availability depends on the active Kodi skin.


## Version 0.2.2 label fix

Settings categories, groups, fields, and option labels now use numeric localization IDs backed by English strings. This corrects blank labels caused by literal text in the version-1 settings schema. Install the updated ZIP and restart Kodi; no profile reset is needed.


## Version 0.2.3 Trakt QR connection

Flux Stream is registered as a Trakt Development application owned by the developer account used for this personal build. The bundled Client ID is public application identity, not a user access token or client secret. Only the owner and explicitly invited development testers can authorize this app; it is not a production-wide registration.

Trakt no longer requires a client secret for this device flow. The app omits the secret from device-token, refresh, and revoke requests when none is configured, while retaining compatibility with explicit legacy credentials. Optional credential overrides have valid empty defaults and are kept at Expert level. Successful login enables Trakt tracking. The sync service waits for first authorization rather than exiting at startup.

The QR uses Trakt's verification URL, or its complete verification URL when one is provided. Trakt may still ask you to enter the short code displayed beside the QR before approval. No Trakt password is entered into Flux Stream.

The corrected build retains the same add-on ID/profile. Install the ZIP over the previous build; do not reset settings or remove the profile. Real device-code creation was accepted by Trakt. Full user authorization, token receipt, and synchronization still need confirmation in Kodi.

## GitHub releases and updates

Development source is maintained in the private [Dean-Flux/flux-stream](https://github.com/Dean-Flux/flux-stream) repository. Public Kodi packages and their complete packaged Python source are hosted in [Dean-Flux/flux-stream-repo](https://github.com/Dean-Flux/flux-stream-repo).

Add `https://dean-flux.github.io/flux-stream-repo/` to Kodi's File manager, install `repository.fluxstream-1.0.0.zip` from that source, then use Install from repository > Flux Stream Repository > Video add-ons > Flux Stream. For an existing manual installation, choose Update or Versions in its information screen and select the Flux Stream Repository build once to associate it with that repository. Leave Auto-update enabled.

Future higher-version builds published to this repository can update through Kodi's add-on manager. The original upstream self-updater remains disabled. Kodi preserves the existing add-on profile because the add-on ID is unchanged. CocoScrapers must still be installed separately from its developer's repository.

To publish an update: bump the add-on version, build with `python package.py`, run `python publish.py <path-to-built-zip>` in the sibling `flux-stream-repo` checkout, review and push the distribution changes. The publisher regenerates the catalog, checksum, and package links. GitHub Pages deploys the updated files. Never replace a published package with different contents under the same version.

## Version 0.2.5 account settings persistence

TorBox and Trakt connection/disconnection buttons close the settings dialog before running. Kodi otherwise routes Python setting writes into the open dialog instead of saving the profile directly; closing or canceling that dialog can lose the account fields despite a successful authorization. After updating, restart Kodi, reconnect from Accounts, and reopen settings to see the saved user and Trakt enabled state. Existing progress and other settings are preserved.

## Version 0.2.6 visible account status

Each account now shows Status: Connected or Status: Not connected. TorBox uses the saved token; Trakt uses the authenticated-account flag. Connect appears only when disconnected; Disconnect and the account field appear only when connected. Use Trakt controls whether Trakt features run and is separate from authorization. These indicators reflect saved authorization, not a live service-health check. The settings-close persistence fix remains in place.

## Version 0.2.7 included TMDB metadata

The owner registered a free personal-use TMDB application and approved bundling its v3 key in public Kodi packages. Fresh profiles and blank overrides use that application key for catalog browsing, title search, and preloading. Optional personal overrides take precedence and remain at Expert settings level. The TMDB read-access bearer token and account credentials are not bundled.

Metadata settings include an About / Credits dialog with the included logo and attribution notice. Live movie and TV catalog requests returned results with the registered application key. CocoScrapers still requires a separate installation; TorBox and Trakt use each family member's own account. The Trakt app remains in Development mode, so family accounts must first be added as invited testers.

## Trakt notice and privacy

Flux Stream uses Trakt but is not endorsed or certified by Trakt.

[Privacy policy](https://dean-flux.github.io/flux-stream-repo/privacy.html) | [Application details and credits](https://dean-flux.github.io/flux-stream-repo/about.html)

Version 0.2.8 adds the Trakt notice to the existing in-app About / Credits dialog. Production access is being requested; no production Client ID has been issued or bundled. Development authorization rules stay in effect until Trakt grants access and a later build includes its production Client ID.

## Version 0.2.9 family setup and browsing

Setup Wizard is always available from the main menu, even when optional home sections are hidden. It checks saved TorBox/Trakt authorization, whether Trakt features are enabled, the installed/enabled CocoScrapers module and its provider toggles, and included TMDB metadata. It reuses the existing QR account connections and refreshes the checklist after each step. Already connected accounts are not reauthorized. Trakt is optional for playback. These are local readiness checks, not online account-health or provider-availability tests.

For missing CocoScrapers, the wizard offers the developer repository installation instructions. If its repository is already installed and enabled, the wizard can ask Kodi to install the module with normal installation prompts. Disabled modules can be enabled by selecting their setup step; installed modules open their settings for provider selection. Flux Stream does not install a third-party repository or change Unknown sources automatically. Back exits safely; selecting Finish opens Movies only when the required local checks pass. New preference steps such as autoplay can be added to the checklist later; this release does not change playback preferences.

Movies adds Top Rated, New Releases (In Theaters), and Upcoming (In Theaters). TV Shows adds Top Rated, Airing Today, and On the Air. The new folders use TMDB without Trakt login and retain normal source selection, metadata, and pagination. The movie release folders describe theatrical schedules rather than guaranteed streaming availability.

## Version 0.3.0 built-in Trakt browsing

Movies and TV Shows now open Trakt discovery directly: Trending, Popular, Most Watched, Popular Lists, Trending Lists, Search Lists, My Lists, Liked Lists, My Watchlist, and Recommendations. The registered application Client ID is included. Public discovery and community lists work without account sign-in or developer-key entry; live unauthenticated requests were verified. Personal folders explain how to connect through Setup Wizard or enable Use Trakt when needed. No personal credentials are included in packages.

Browse TMDB remains a submenu with the expanded TMDB categories. TMDB metadata and artwork remain included through the registered application key. Existing source selection and playback routes are reused. Public Trakt list links now retain their numeric IDs so lists without owner slugs can open correctly. Popular title results retain pagination and use the existing TMDB enrichment/playback renderer.

Only invitation-free personal Trakt login depends on pending Production access. Public browsing does not require the family member to be an invited tester. Focused Trakt and metadata/wizard test groups are verified separately because combined Kodi mocks can interfere with each other.

## Version 0.3.1 neutral menu icons

Trakt-backed browsing folders now use the existing movie/TV icons. Other Trakt menu entries use neutral category/progress artwork instead of the Trakt logo. Trakt data sources and required credits stay in place.

## Version 0.3.2 Flux Stream branding

Original retro-futurist artwork replaces the inherited Jacktook app icon, browsing background, resolver fallback background, and source-selection clearlogos. The palette is midnight navy, orange, amber, teal, and warm ivory with a signal-ribbon/orbital mark. The icon is 512 x 512, fanart is 1920 x 1080, and the overlay wordmark has a cleaned transparent alpha channel. Artwork-specific file names prevent Kodi from reusing cached upstream art. Old upstream promotional screenshots are no longer advertised in the manifest. Original code attribution and service credits remain intact.

## Version 0.3.3 matching menu icons

Original mission-style menu badges use Flux Stream's midnight navy, ivory, orange, amber, and teal palette. Main navigation, discovery folders, lists, pagination, and utility menus share the set. Movies and TV have distinct Trending, Popular, Most Watched, Lists, Watchlist, and Recommendations symbols; the Setup Wizard has its own badge. TMDB's official credit artwork remains intact. Icons are rendered by the development-only `scripts/generate_menu_icons.py`; Kodi needs no additional dependency.

## Version 0.3.4 My Trakt

The main menu adds My Trakt with In Progress, Watch History, Watchlist, My Lists, Liked Lists, Collection, Favorites, and Recommendations. Each category splits into Movies and TV Shows. Movie progress uses the existing Trakt resume flow, preserving playback IDs and resume positions; TV progress shows resumed/next unwatched episodes of started series using the existing Up Next feed. Personal feeds require a connected, enabled Trakt account. Dashboard settings can hide My Trakt or make it the first section. Existing Continue Watching, Watchlist, public discovery, and profile data remain available.

## Version 0.3.5 TV pack discovery

CocoScrapers now checks full-series packs as well as episodes and single-season packs, using the TMDB season count and the existing scraper deadline/cancellation. Pack mapping rejects show packs that end before the requested season and partial-season packs missing the requested episode. Validated pack-season metadata preserves matching packs through episode filtering. Old incomplete search caches are bypassed. Empty cached-only searches now explain that no TorBox cached sources survived filtering; actual availability still depends on the enabled providers and TorBox cache.

## Version 0.3.6 Trakt series progress

My Trakt > In Progress > TV Shows now lists started series with unwatched aired episodes, including shows between episodes and paused-only shows. Watch History > Completed TV Shows lists series caught up through every regular aired episode. Both open show seasons rather than an episode search. Specials and repeat plays do not inflate completion; reset progress is respected, and hidden progress shows stay hidden. A returning show can move back to In Progress when a new episode airs. Movie progress/history and the separate episode-resume view remain unchanged. Watched-show requests now use Trakt's extended=progress response and load all pages.

## Version 0.3.7 episode watched indicators

Episode rows now pass the parent show TMDB ID and season/episode numbers to the existing Trakt watched/resume lookup. Episode metadata is copied so cached TMDB details and episode IDs remain intact. This restores Kodi watched marks and resume indicators for tracked episodes without changing Trakt records.

## Version 0.3.8 series watched counts

My Trakt In Progress and Completed TV Shows display watched/total aired regular episodes beside each show title (for example, 22/100 watched). Counts reuse the progress classification, excluding specials and duplicate watches and respecting progress resets. Unknown totals display a question mark. Show titles, metadata, and season links remain canonical.

## Version 0.3.9 completed season marks

Season folders receive Kodi's watched checkmark when every currently aired regular episode in that season appears in the local Trakt watched cache. Future episodes do not block the mark. Empty seasons, specials, unknown air dates, or unavailable metadata are not marked completed. Seasons with no watched episodes skip metadata requests. Both routed and direct season/episode directories refresh dynamic watched indicators on reentry. Includes the series watched counts from 0.3.8.
