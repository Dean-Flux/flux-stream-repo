import re
from collections import Counter
from contextlib import contextmanager
from contextvars import ContextVar

from xbmcgui import WindowXMLDialog

from lib.utils.kodi.utils import ADDON_PATH


_autoplay_progress = ContextVar("autoplay_progress", default=None)


def current_autoplay_progress():
    return _autoplay_progress.get()


@contextmanager
def autoplay_progress(title):
    dialog = AutoplayDialog("autoplay.xml", ADDON_PATH)
    token = _autoplay_progress.set(dialog)
    try:
        dialog.setProperty("Title", title)
        dialog.setProperty("Stage", "Finding sources...")
        dialog.show()
        yield dialog
    finally:
        try:
            dialog.finish()
        finally:
            _autoplay_progress.reset(token)


def _resolution(quality):
    return re.sub(r"\[[^]]*\]", "", quality or "").strip().lower()


class AutoplayDialog(WindowXMLDialog):
    cancelled = False
    finished = False

    def set_sources(self, sources):
        counts = Counter(_resolution(source.quality) for source in sources)
        four_k = counts["4k"] + counts["2160p"]
        standard = counts["1080p"] + counts["720p"] + counts["480p"]
        other = len(sources) - four_k - standard
        self.setProperty("Counts", (
            f'4K {four_k}  |  1080p {counts["1080p"]}  |  '
            f'720p {counts["720p"]}  |  480p {counts["480p"]}  |  Other {other}'
        ))

    def set_attempt(self, number, total, source):
        service = {"Torbox": "TorBox", "RealDebrid": "Real-Debrid"}.get(
            source.debridType, source.debridType or getattr(source, "provider", "") or ""
        )
        self.setProperty("Stage", f"Trying source {number} of {total}  |  {_resolution(source.quality)}  |  {service}")
        self.setProperty("Source", source.title)

    def create(self, *_args):
        pass

    def update(self, *_args):
        pass

    def iscanceled(self):
        return self.cancelled

    def onClick(self, control_id):
        if control_id == 10:
            self.cancelled = True
            self.setProperty("Stage", "Cancelling...")

    def onAction(self, _action):
        pass  # Only the visible Cancel button may interrupt an attempt.

    def finish(self):
        if not self.finished:
            self.finished = True
            self.close()
