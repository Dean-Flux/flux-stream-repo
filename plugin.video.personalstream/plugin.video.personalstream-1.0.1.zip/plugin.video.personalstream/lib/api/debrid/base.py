from urllib.parse import urlsplit
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional

import requests

from lib.utils.kodi.utils import kodilog, notification


class DebridClient(ABC):
    """
    Abstract base class for Debrid service clients.

    Handles HTTP requests, error handling, and session management.
    """

    def __init__(self, token: str, timeout: int = 15, session: Optional[requests.Session] = None):
        """Initialize the debrid client.

        Args:
            token (str): API token for authentication.
            timeout (int): Request timeout in seconds.
            session (requests.Session, optional): Custom session for requests.
        """
        self.token = token

        self.timeout = timeout
        self.session = session or requests.Session()
        self.headers = {}
        self.initialize_headers()

    def _make_request(
        self,
        method: str,
        url: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
        is_return_none: bool = False,
        is_expected_to_fail: bool = False,
    ) -> Dict[str, Any]:
        """
        Make an HTTP request and handle errors.
        """
        response = self._perform_request(method, url, data, params, json)
        self._handle_errors(response, is_expected_to_fail)
        return self._parse_response(response, is_return_none)

    def _perform_request(
        self,
        method: str,
        url: str,
        data: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        json: Optional[Dict[str, Any]] = None,
    ) -> requests.Response:
        """
        Perform the actual HTTP request.
        """
        try:
            return self.session.request(
                method=method,
                url=url,
                params=params,
                data=data,
                json=json,
                headers=self.headers,
                timeout=self.timeout,
            )
        except Exception as error:
            host = urlsplit(url).hostname or "provider"
            kodilog(f"Debrid request failed: {method} {host} ({type(error).__name__})")
            if isinstance(error, requests.exceptions.Timeout):
                raise ProviderException("Debrid request timed out.") from None
            raise ProviderException("Could not contact the debrid service. Try again shortly.") from None

    def _handle_errors(self, response: requests.Response, is_expected_to_fail: bool) -> None:
        """
        Handle HTTP errors and raise ProviderException as needed.
        """
        if is_expected_to_fail or response.status_code < 400:
            return

        status_code = response.status_code
        if response.headers.get("Content-Type", "").startswith("application/json"):
            try:
                error_data = response.json()
            except ValueError:
                error_data = None
            if isinstance(error_data, dict):
                self._handle_service_specific_errors(error_data, status_code)
        messages = {401: "Invalid token", 403: "Forbidden", 500: "Internal server error"}
        raise ProviderException(messages.get(status_code, "Debrid request failed"), status_code)

    @abstractmethod
    def initialize_headers(self) -> None:
        """
        Initialize headers for requests. Must be implemented by subclasses.
        """
        raise NotImplementedError

    @abstractmethod
    def disable_access_token(self):
        """
        Disable or revoke the access token. Must be implemented by subclasses.
        """
        raise NotImplementedError

    @staticmethod
    def _parse_response(response: requests.Response, is_return_none: bool) -> Dict[str, Any]:
        """
        Parse the HTTP response as JSON.
        """
        if is_return_none:
            return {}
        try:
            return response.json()
        except ValueError:
            raise ProviderException("Debrid returned an unreadable reply.", response.status_code) from None

    @abstractmethod
    def _handle_service_specific_errors(self, error_data: dict, status_code: int) -> None:
        """
        Service specific errors on api requests. Must be implemented by subclasses.
        """
        raise NotImplementedError


class ProviderException(Exception):
    notify_on_raise = True

    def __init__(self, message: str, status_code: Optional[int] = None, error_content: Any = None):
        self.message = message
        self.status_code = status_code
        self.error_content = error_content
        details = f"{self.message}"
        if self.status_code is not None:
            details += f" (Status code: {self.status_code})"
        super().__init__(details)
        if self.notify_on_raise:
            notification(details)
