import json

import xbmc

from lib.gui.play_window import PlayWindow
from lib.utils.kodi.utils import kodilog, set_property


def _safe_text(value):
    if value is None:
        return ""
    return str(value)


def _safe_int(value):
    try:
        if value in (None, ""):
            return None
        return int(value)
    except (TypeError, ValueError):
        return None


def _dict_value(data, *keys):
    if not isinstance(data, dict):
        return ""
    for key in keys:
        value = data.get(key)
        if value not in (None, ""):
            return value
    return ""


def build_next_episode_properties(item_information):
    item_information = item_information or {}
    tv_data = item_information.get("tv_data") or {}
    next_tv_data = item_information.get("next_tv_data") or {}

    if not isinstance(tv_data, dict):
        tv_data = {}
    if not isinstance(next_tv_data, dict):
        next_tv_data = {}

    season = _safe_int(next_tv_data.get("season"))
    episode = _safe_int(next_tv_data.get("episode"))

    if season is None:
        season = _safe_int(tv_data.get("season"))

    if episode is None:
        current_episode = _safe_int(tv_data.get("episode"))
        if current_episode is not None:
            episode = current_episode + 1

    if season is not None and episode is not None:
        episode_label = f"S{season:02d}E{episode:02d}"
    elif episode is not None:
        episode_label = f"Episode {episode}"
    else:
        episode_label = ""

    episode_name = _safe_text(_dict_value(next_tv_data, "name", "title", "episode_name"))
    if not episode_name and episode is not None:
        episode_name = f"Episode {episode}"

    title = _safe_text(
        _dict_value(
            item_information,
            "show_title",
            "tvshowtitle",
            "series_title",
            "query",
            "title",
            "next_label",
        )
    )

    return {
        "next.title": title,
        "next.poster": _safe_text(_dict_value(item_information, "poster", "thumb", "icon")),
        "next.fanart": _safe_text(_dict_value(item_information, "fanart", "backdrop")),
        "next.clearlogo": _safe_text(_dict_value(item_information, "clearlogo")),
        "next.season": "" if season is None else str(season),
        "next.episode": "" if episode is None else str(episode),
        "next.episode_label": episode_label,
        "next.episode_name": episode_name,
        "next.plot": _safe_text(_dict_value(item_information, "plot", "overview")),
    }


class PlayNext(PlayWindow):
    def __init__(self, xml_file, xml_location, item_information=None):
        super().__init__(xml_file, xml_location, item_information=item_information)
        self.default_action = 2
        self._set_next_episode_properties(item_information or {})

    def _set_next_episode_properties(self, item_information):
        for key, value in build_next_episode_properties(item_information).items():
            self.setProperty(key, value)

    def background_tasks(self):
        try:
            try:
                progress_bar = self.getControl(3014)
            except (RuntimeError, AttributeError):
                progress_bar = None
            self.duration = max(self.getTotalTime() - self.getTime(), 1)
            while not self.closed and self.playing_file and self.playing_file == self.getPlayingFile():
                remaining = max(0, int(self.getTotalTime() - self.getTime()))
                self.setProperty("timer", str(remaining))
                self.setProperty("timer_label", f"Next at end: {remaining}s")
                if progress_bar is not None and hasattr(progress_bar, "setPercent"):
                    progress_bar.setPercent(min(100, max(0, self.calculate_percent())))
                xbmc.sleep(500)
        except Exception as e:
            kodilog(f"Error updating PlayNext: {e}")
        if self.action is None and not self.closed:
            self.action = "finished"
        self.close()

    def close(self):
        if self.action is None:
            self.action = "close"
        session_id = (getattr(self, "item_information", None) or {}).get("playback_session_id")
        if self.action == "close" and session_id:
            # Cancel before the close animation can race the end-of-file callback.
            set_property("personalstream_next_dialog_action", json.dumps({"action": "close", "session_id": session_id}))
        super().close()

    def smart_play_action(self):
        # Automatic continuation belongs to the owning player's natural-end event.
        pass
