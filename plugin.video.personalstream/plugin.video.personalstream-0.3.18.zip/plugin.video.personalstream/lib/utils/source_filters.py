"""Literal release-name and video-container filters shared by search and playback."""

import os

from lib.utils.kodi.utils import get_setting

VIDEO_EXTENSIONS = {"mkv", "mp4", "m4v", "avi", "webm", "mov", "ts", "m2ts", "wmv", "mpg", "mpeg", "flv", "vob", "3gp", "ogv"}


def terms(setting):
    value = get_setting(setting, "")
    return [part.strip().lower() for part in value.split(",") if part.strip()] if isinstance(value, str) else []


def file_type_allowed(filename, allow_unknown=False):
    allowed = {value.lstrip(".") for value in terms("allowed_file_types")}
    if not allowed:
        return True
    extension = os.path.splitext(str(filename))[1].lower().lstrip(".")
    if allow_unknown and extension not in VIDEO_EXTENSIONS:
        return True  # Release labels often omit the container; resolve the actual file before play.
    return extension in allowed


def filter_release_names(results):
    required = terms("required_name_terms")
    excluded = terms("excluded_name_terms")
    return [
        item for item in results
        if all(term in item.title.lower() for term in required)
        and not any(term in item.title.lower() for term in excluded)
        and file_type_allowed(item.title, allow_unknown=True)
    ]
