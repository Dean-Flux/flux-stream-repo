"""Minimal background services for Flux Stream."""

from threading import Thread

import xbmc
import xbmcaddon

from lib.api.trakt.base_cache import setup_databases
from lib.services.trakt_sync import TraktSyncService
from lib.utils.kodi.utils import (
    ADDON_VERSION,
    clear_cached_settings,
    clear_property,
    dialog_ok,
    get_kodi_version,
    kodilog,
    set_property_no_fallback,
    set_setting,
    translation,
)

pause_services_prop = "personalstream.pause_services"


class CheckKodiVersion:
    def run(self):
        kodilog("Checking Kodi version...")
        if get_kodi_version() < 20:
            dialog_ok(
                heading=xbmcaddon.Addon().getAddonInfo("name"),
                line1=translation(90559),
            )



class JacktookMOnitor(xbmc.Monitor):
    def __init__(self):
        # super() resolves through this class's MRO (base captured at import)
        # instead of re-reading the xbmc module attribute at call time; on
        # Kodi 22 beta that attribute was observed corrupted at runtime.
        super().__init__()
        self.startServices()

    def startServices(self):
        set_setting("addon_version", ADDON_VERSION)
        CheckKodiVersion().run()
        setup_databases()
        Thread(target=TraktSyncService().run).start()

    def onScreensaverActivated(self):
        set_property_no_fallback(pause_services_prop, "true")
        kodilog("PAUSING Flux Stream services Due to Device Sleep", level=xbmc.LOGINFO)

    def onScreensaverDeactivated(self):
        clear_property(pause_services_prop)
        kodilog("UNPAUSING Flux Stream services Due to Device Awake", level=xbmc.LOGINFO)

    def onSettingsChanged(self):
        clear_cached_settings()
        from lib.utils.tmdb_init import ensure_tmdb_init

        ensure_tmdb_init()
        kodilog(
            "Cleared cached settings and refreshed TMDB language after Kodi settings change",
            level=xbmc.LOGINFO,
        )

    def onNotification(self, sender, method, data):
        if method == "System.OnSleep":
            set_property_no_fallback(pause_services_prop, "true")
            kodilog(
                "PAUSING Flux Stream services Due to Device Sleep",
                level=xbmc.LOGINFO,
            )
        elif method == "System.OnWake":
            clear_property(pause_services_prop)
            kodilog(
                "UNPAUSING Flux Stream services Due to Device Awake",
                level=xbmc.LOGINFO,
            )
