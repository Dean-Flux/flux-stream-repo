"""Manual package updates only; the upstream installer is intentionally removed."""

from lib.utils.kodi.utils import notification


def updates_check_addon(automatic=False):
    if not automatic:
        notification("Updates are disabled. Install a Flux Stream ZIP to update.")
    return False
