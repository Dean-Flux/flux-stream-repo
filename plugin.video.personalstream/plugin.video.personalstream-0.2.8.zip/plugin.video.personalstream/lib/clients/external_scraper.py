import json
import os
import sys
from queue import Empty, Queue
from threading import BoundedSemaphore, Event, Thread
from time import monotonic
from typing import Any, Callable, List, Optional, Tuple

from lib.clients.base import BaseClient
from lib.domain.torrent import TorrentStream
from lib.utils.general.utils import Indexer
from lib.utils.kodi.utils import kodilog

_BYTES_PER_GB = 1073741824
_PROVIDER_SLOTS = BoundedSemaphore(8)


class ExternalScraperClient(BaseClient):
    """Generic client for external scraper modules.

    Accepts any ``xbmc.python.module`` addon that exposes a ``sources()``
    function returning provider tuples.  The module is a soft dependency:
    if the addon is not installed or fails to import, ``initialized`` is
    ``False`` and searches return an empty list.

    The data dict passed to providers:

    * Movies: ``{imdb, title, aliases, year}``
    * TV: ``{imdb, tvdb, tvshowtitle, title, aliases, year, season, episode}``
    """

    def __init__(
        self,
        module_id: str,
        module_display_name: str,
        notification: Optional[Callable],
    ) -> None:
        super().__init__(None, notification)
        self.module_id = module_id
        self.module_name = module_id.split(".")[-1]
        self.module_display_name = module_display_name
        self._sources_func = None
        self._providers = None
        self.cancelled = False
        self.timed_out = False
        self.initialized = self._init_providers()

    # ------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------

    def _init_providers(self) -> bool:
        """Locate the addon and import its provider list.

        .. note::
            ``sys.path`` is **not** restored after import.  Providers
            perform runtime imports inside their ``sources()`` methods,
            so the library path must remain on ``sys.path`` for the
            lifetime of the client.
        """
        addon_path = self._resolve_addon_path()
        if not addon_path:
            kodilog(f"ExternalScraper ({self.module_id}): addon not found")
            return False

        lib_path = os.path.join(addon_path, "lib")
        if not os.path.isdir(lib_path):
            kodilog(f"ExternalScraper ({self.module_id}): lib dir not found at {lib_path}")
            return False

        if lib_path not in sys.path:
            sys.path.insert(0, lib_path)

        try:
            # Import the top-level package
            module = __import__(self.module_name, fromlist=["sources"])
            self._sources_func = module.sources
            self._providers = self._sources_func(specified_folders=["torrents"])
            provider_count = len(self._providers) if self._providers else 0
            kodilog(f"ExternalScraper ({self.module_id}): loaded {provider_count} providers")
            return bool(self._providers)
        except Exception as exc:
            kodilog(f"ExternalScraper ({self.module_id}): failed to import providers: {exc}")
            return False

    def _resolve_addon_path(self) -> Optional[str]:
        """Locate the addon path via xbmcaddon or JSON-RPC."""
        # 1) xbmcaddon (fastest)
        try:
            import xbmcaddon

            addon = xbmcaddon.Addon(self.module_id)
            return addon.getAddonInfo("path")
        except Exception:
            pass

        # 2) JSON-RPC fallback
        try:
            import xbmc

            response = xbmc.executeJSONRPC(
                json.dumps(
                    {
                        "jsonrpc": "2.0",
                        "method": "Addons.GetAddonDetails",
                        "params": {
                            "addonid": self.module_id,
                            "properties": ["path"],
                        },
                        "id": 1,
                    }
                )
            )
            data = json.loads(response)
            return data.get("result", {}).get("addon", {}).get("path")
        except Exception as exc:
            kodilog(f"ExternalScraper ({self.module_id}): JSON-RPC fallback failed: {exc}")
            return None

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def search(
        self,
        tmdb_id: str,
        query: str,
        mode: str,
        media_type: str,
        season: Optional[int],
        episode: Optional[int],
        imdb_id: str = "",
        tvdb_id: str = "",
        year: str = "",
        aliases: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> List[TorrentStream]:
        self.cancelled = False
        self.timed_out = False
        kodilog(
            f"[ExternalScraper ({self.module_id})] search() called: "
            f"query={query}, mode={mode}, imdb={imdb_id}, year={year}, aliases={aliases}, "
            f"providers={len(self._providers) if self._providers else 0}"
        )
        if not self.initialized or not self._providers:
            kodilog(f"[ExternalScraper ({self.module_id})] not initialised, returning empty")
            return []

        is_tv = mode == "tv" or media_type == "tv"

        data = self._build_data(
            query=query,
            mode=mode,
            season=season,
            episode=episode,
            imdb_id=imdb_id,
            tvdb_id=tvdb_id,
            year=year,
            aliases=aliases,
        )

        cancel_check = kwargs.get("cancel_check") or (lambda: False)
        try:
            timeout = float(kwargs.get("timeout", 20))
        except (TypeError, ValueError):
            timeout = 20
        if not 0 < timeout <= 120:
            timeout = 20
        deadline = monotonic() + timeout
        stop = Event()
        jobs, completed = Queue(), Queue()
        results_by_provider = {}

        for index, (name, source_class) in enumerate(self._providers):
            capability = "hasEpisodes" if is_tv else "hasMovies"
            if getattr(source_class, capability, True):
                jobs.put((index, name, source_class))

        def publish(index, results, name, is_pack=False):
            if not stop.is_set() and monotonic() < deadline and results:
                completed.put((index, self._map_results(results, name, is_pack=is_pack)))

        def worker():
            try:
                while not stop.is_set() and monotonic() < deadline:
                    try:
                        index, name, source_class = jobs.get_nowait()
                    except Empty:
                        break
                    try:
                        instance = source_class()
                        provider_data = dict(data)
                        publish(index, instance.sources(provider_data, {}), name)
                        if not stop.is_set() and monotonic() < deadline and is_tv and getattr(source_class, "pack_capable", False):
                            publish(index, instance.sources_packs(provider_data, {}), name, is_pack=True)
                    except Exception as exc:
                        if not stop.is_set():
                            kodilog(f"ExternalScraper: provider '{name}' failed: {exc}")
            finally:
                _PROVIDER_SLOTS.release()
                completed.put((None, None))

        workers = 0
        for _ in range(min(jobs.qsize(), 8)):
            if not _PROVIDER_SLOTS.acquire(blocking=False):
                break
            try:
                # shortcut: running provider calls cannot be killed; use process isolation
                # if providers routinely ignore HTTP timeouts. Outstanding workers stay capped.
                Thread(target=worker, daemon=True).start()
                workers += 1
            except Exception:
                stop.set()
                _PROVIDER_SLOTS.release()
                raise
        if not workers and not jobs.empty() and self.notification:
            self.notification("Scraper workers are still busy. Try again shortly.")

        def receive(message):
            index, results = message
            if index is not None:
                results_by_provider.setdefault(index, []).extend(results)
            return index is None

        try:
            while workers:
                if cancel_check():
                    self.cancelled = True
                    break
                remaining = deadline - monotonic()
                if remaining <= 0:
                    self.timed_out = True
                    break
                try:
                    workers -= receive(completed.get(timeout=min(0.05, remaining)))
                except Empty:
                    pass
        finally:
            stop.set()
        if not self.cancelled and not jobs.empty() and monotonic() >= deadline:
            self.timed_out = True
        # Only this invocation's collector owns returned results; late workers cannot
        # update the UI, cache, or result list of this or a subsequent search.
        while True:
            try:
                receive(completed.get_nowait())
            except Empty:
                break
        return [result for index in sorted(results_by_provider) for result in results_by_provider[index]]

    # ------------------------------------------------------------------
    # Data mapping helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _build_data(
        query: str,
        mode: str,
        season: Optional[int],
        episode: Optional[int],
        imdb_id: str = "",
        tvdb_id: str = "",
        year: str = "",
        aliases: Optional[List[str]] = None,
    ) -> dict:
        """Build the data dict that external providers expect.

        Matches the convention:

        * Movies: ``{imdb, title, aliases, year}``
        * TV: ``{imdb, tvdb, tvshowtitle, title, aliases, year, season, episode}``
        """
        is_tv = mode in ("tv", "episode")

        data: dict = {
            "aliases": aliases or [],
            "year": str(year) if year else "",
        }

        if imdb_id:
            data["imdb"] = imdb_id

        if is_tv:
            data["tvshowtitle"] = query
            data["title"] = ""
            data["season"] = str(season) if season else ""
            data["episode"] = str(episode) if episode else ""
            if tvdb_id:
                data["tvdb"] = tvdb_id
        else:
            data["title"] = query

        return data

    def _map_results(
        self,
        results: list,
        provider_name: str,
        is_pack: bool = False,
    ) -> List[TorrentStream]:
        """Map external provider result dicts to Jacktook TorrentStream."""
        mapped: List[TorrentStream] = []

        for item in results:
            try:
                info_hash = (item.get("hash") or "").lower()
                url = item.get("url", "") or ""

                # Some legacy providers put the hash in url as "magnet:HASH"
                # without the ?xt=urn:btih: prefix and leave hash empty.
                if url.startswith("magnet:") and not url.startswith("magnet:?"):
                    legacy_hash = url[7:].strip()
                    if legacy_hash:
                        info_hash = legacy_hash.lower()
                        url = f"magnet:?xt=urn:btih:{info_hash}"

                if info_hash and not url.startswith("magnet:?"):
                    url = f"magnet:?xt=urn:btih:{info_hash}"

                raw_size = item.get("size", 0)
                try:
                    size_bytes = int(float(raw_size) * _BYTES_PER_GB) if raw_size else 0
                except (ValueError, TypeError):
                    size_bytes = 0

                package = item.get("package")
                result_is_pack = is_pack or package in ("season", "show")

                try:
                    seeders = int(item.get("seeders", 0) or 0)
                except (ValueError, TypeError):
                    seeders = 0

                quality = item.get("quality", "") or "N/A"
                title = item.get("name", "") or ""

                mapped.append(
                    TorrentStream(
                        title=title,
                        type="torrent",
                        indexer=Indexer.EXTERNAL_SCRAPER,
                        subindexer=provider_name,
                        addonInstanceLabel=self.module_display_name,
                        infoHash=info_hash,
                        url=url,
                        size=size_bytes,
                        seeders=seeders,
                        quality=quality,
                        provider=provider_name,
                        isPack=result_is_pack,
                        publishDate="",
                    )
                )
            except Exception as exc:
                kodilog(f"ExternalScraper: failed to map result: {exc}")
                continue

        return mapped

    # ------------------------------------------------------------------
    # BaseClient contract
    # ------------------------------------------------------------------

    def parse_response(self, res) -> List[TorrentStream]:
        """Not used — ExternalScraperClient does not make HTTP requests."""
        return []
