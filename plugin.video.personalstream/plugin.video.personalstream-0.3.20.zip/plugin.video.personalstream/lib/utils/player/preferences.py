"""Language matching shared by Flux Stream's audio and subtitle preferences."""

import xbmc


def language_matches(stream_language, preferred_language):
    if not stream_language or preferred_language in (None, "", "None"):
        return False
    actual = xbmc.convertLanguage(str(stream_language).split("-")[0].strip(), xbmc.ISO_639_2)
    preferred = xbmc.convertLanguage("Indonesian" if preferred_language == "Indonesia" else preferred_language, xbmc.ISO_639_2)
    return isinstance(actual, str) and isinstance(preferred, str) and bool(actual) and actual == preferred
