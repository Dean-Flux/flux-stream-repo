# Flux Stream

A personal Kodi add-on foundation based on [Jacktook](https://github.com/Sam-Max/plugin.video.jacktook) by Sam-Max.

The supported configuration is TorBox for playback, CocoScrapers for discovery, Trakt for tracking, and TMDB for metadata and artwork. IMDb IDs remain part of title matching. TorBox authorization and cached playback have been confirmed on the owner's Kodi device; Trakt QR authorization still needs live confirmation.

## Identity and isolation

- Display name: Flux Stream
- Add-on ID: `plugin.video.personalstream`
- Version: `0.2.5`
- Kodi-managed profile: `special://profile/addon_data/plugin.video.personalstream/`
- Private session properties use the `personalstream` namespace.
- The upstream updater, installation helper, automatic TMDBHelper writes, donation prompt, and unrelated background services have been removed from the active flow.
- No existing Jacktook account settings or databases are migrated or modified.

## Setup

1. Use Kodi 21 as the initial development target. Other versions and playback hardware still need validation.
2. Install and enable `script.module.cocoscrapers` separately from its developer's repository. This build does not install third-party repositories automatically.
3. Install the Flux Stream ZIP using Kodi's Install from zip file action.
4. Under Settings > Accounts, authorize TorBox.
5. Under Settings > Metadata, supply your own TMDB API key. Browse/search reports a setup message when it is missing; TorBox Cloud can be used separately.
6. For Trakt, choose Accounts > Connect Trakt (QR code), scan the displayed QR code, enter the short activation code if prompted, and approve Flux Stream. Its public development-app Client ID is bundled; a client secret is not required. Tracking enables after successful authorization and background sync waits for the initial connection. Optional developer overrides are available only at Expert settings level.

Sources are cached-only. Manual source selection is the default. Retired integrations are disabled by runtime settings even if an imported profile contains old flags. Their code remains where shared imports still require it; this is a narrowed foundation, not a completed removal of every unused module.

Continue Watching separates local progress and Trakt progress. Combining those feeds and reconciling offline conflicts is later work. Scraper searches have a configurable 20-second default deadline. Timeout returns completed sources without caching the incomplete search. Cancel stops the flow before filtering, cache checks, or playback. At most eight daemon provider workers may be outstanding in one interpreter; queued work stops on timeout/cancel and late results are discarded. Python cannot forcibly interrupt a blocked third-party network call, so a busy worker may remain until its provider returns. Both legacy search presentation settings use the same native cancelable progress dialog.

## Local Windows development

From this checkout in PowerShell, use an isolated environment:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-test.txt
.\.venv\Scripts\python.exe -m pytest tests/unit/test_personalstream_foundation.py tests/unit/test_settings_xml.py tests/unit/test_updater.py
.\.venv\Scripts\python.exe package.py
```

The package is written to `dist/plugin.video.personalstream-0.2.5.zip`. Use `python package.py --output <directory>` to choose another destination. Tests, development configuration, caches, the original player-helper ZIP, and repository metadata are excluded. The ZIP contains the required `plugin.video.personalstream/` top-level folder.

The larger upstream suite has test isolation/mock failures in a combined Windows run, observed before this fork changed the code. Run relevant integration groups separately and distinguish these baseline failures from regressions.

## Attribution and licensing

Original Jacktook source snapshot: `cb3bd2d2dc08dd35a98aabc668f319e31137fff9`.

Original copyright notices and the upstream LICENSE are retained. Upstream LICENSE contains GPL version 3, while addon.xml declares GPL-2.0-only. This discrepancy is unresolved; clarify it before distributing a derivative. Artwork is inherited from upstream and remains a development placeholder.

TMDB attribution: This product uses the TMDB API but is not endorsed or certified by TMDB. A final branded release must include the required TMDB attribution/logo treatment.

Validate Trakt account authorization, CocoScrapers compatibility, movie and episode playback, seeking/resume, and Trakt progress on the target device before treating the build as ready for use.


## Search controls and filters

Movies and individual TV episodes retain their Rescrape and Source Select context-menu actions. Rescrape bypasses cached search results and the quick-play shortcut. Source Select forces the manual chooser even when autoplay is enabled.

Settings > Sources controls the scraper deadline, from 5 to 120 seconds. Cancel stops the search; a timeout can still show sources completed before the deadline. A timeout does not write partial results as a complete cached search.

Settings > Filtering includes minimum/maximum reported release sizes in MiB, literal case-insensitive name filters, allowed containers, codec preferences, and HDR preferences. Required name terms are comma-separated and all must occur; any excluded term removes a release. Blank fields disable those filters. Unknown source sizes are retained. Season-pack sizes are reported release sizes, not per-episode sizes.

Allowed containers can be entered as `mkv, mp4` or `.mkv, .mp4`. A release with no identifiable container can remain in the source list; the actual TorBox filename is checked before generating a playback link, including cloud and pack playback. File-type filtering does not change the underlying codec.

Settings > Home menu lets you hide optional sections, choose Continue Watching/Movies/TV Shows as the first visible section, and open Kodi's existing section-view chooser. Settings remains available even when every optional section is hidden. View availability depends on the active Kodi skin.


## Version 0.2.2 label fix

Settings categories, groups, fields, and option labels now use numeric localization IDs backed by English strings. This corrects blank labels caused by literal text in the version-1 settings schema. Install the updated ZIP and restart Kodi; no profile reset is needed.


## Version 0.2.3 Trakt QR connection

Flux Stream is registered as a Trakt Development application owned by the developer account used for this personal build. The bundled Client ID is public application identity, not a user access token or client secret. Only the owner and explicitly invited development testers can authorize this app; it is not a production-wide registration.

Trakt no longer requires a client secret for this device flow. The app omits the secret from device-token, refresh, and revoke requests when none is configured, while retaining compatibility with explicit legacy credentials. Optional credential overrides have valid empty defaults and are kept at Expert level. Successful login enables Trakt tracking. The sync service waits for first authorization rather than exiting at startup.

The QR uses Trakt's verification URL, or its complete verification URL when one is provided. Trakt may still ask you to enter the short code displayed beside the QR before approval. No Trakt password is entered into Flux Stream.

The corrected build retains the same add-on ID/profile. Install the ZIP over the previous build; do not reset settings or remove the profile. Real device-code creation was accepted by Trakt. Full user authorization, token receipt, and synchronization still need confirmation in Kodi.

## GitHub releases and updates

Development source is maintained in the private [Dean-Flux/flux-stream](https://github.com/Dean-Flux/flux-stream) repository. Public Kodi packages and their complete packaged Python source are hosted in [Dean-Flux/flux-stream-repo](https://github.com/Dean-Flux/flux-stream-repo).

Add `https://dean-flux.github.io/flux-stream-repo/` to Kodi's File manager, install `repository.fluxstream-1.0.0.zip` from that source, then use Install from repository > Flux Stream Repository > Video add-ons > Flux Stream. For an existing manual installation, choose Update or Versions in its information screen and select the Flux Stream Repository build once to associate it with that repository. Leave Auto-update enabled.

Future higher-version builds published to this repository can update through Kodi's add-on manager. The original upstream self-updater remains disabled. Kodi preserves the existing add-on profile because the add-on ID is unchanged. CocoScrapers must still be installed separately from its developer's repository.

To publish an update: bump the add-on version, build with `python package.py`, run `python publish.py <path-to-built-zip>` in the sibling `flux-stream-repo` checkout, review and push the distribution changes. The publisher regenerates the catalog, checksum, and package links. GitHub Pages deploys the updated files. Never replace a published package with different contents under the same version.

## Version 0.2.5 account settings persistence

TorBox and Trakt connection/disconnection buttons close the settings dialog before running. Kodi otherwise routes Python setting writes into the open dialog instead of saving the profile directly; closing or canceling that dialog can lose the account fields despite a successful authorization. After updating, restart Kodi, reconnect from Accounts, and reopen settings to see the saved user and Trakt enabled state. Existing progress and other settings are preserved.
