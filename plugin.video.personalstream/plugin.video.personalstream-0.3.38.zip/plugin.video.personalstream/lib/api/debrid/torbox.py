import datetime
import ipaddress

import xbmc

import requests
from requests.adapters import HTTPAdapter

from lib.api.debrid.base import DebridClient, ProviderException
from lib.services.debrid.auth import run_torbox_auth
from lib.utils.kodi.utils import (
    dialog_ok,
    kodilog,
    notification,
    set_setting,
    translation,
)


class Torbox(DebridClient):
    def __init__(self, token, timeout=15):
        session = requests.Session()
        adapter = HTTPAdapter(max_retries=1)
        session.mount("https://", adapter)
        super().__init__(token, timeout, session)

    BASE_URL = "https://api.torbox.app/v1/api"
    CLOUD_CACHE_KEY = "cloud_downloads|Torbox|1|files-v2"

    def initialize_headers(self):
        self.headers = {
            "User-Agent": "Jacktook/1.0",
            "Accept": "application/json",
        }
        if self.token:
            self.headers["Authorization"] = f"Bearer {self.token}"

    def disable_access_token(self):
        pass

    def _handle_service_specific_errors(self, error_data: dict, status_code: int):
        error_code = error_data.get("error")
        if error_code in {"BAD_TOKEN", "AUTH_ERROR", "OAUTH_VERIFICATION_ERROR"}:
            raise ProviderException("Invalid Torbox token")
        elif error_code == "DOWNLOAD_TOO_LARGE":
            raise ProviderException("Download size too large for the user plan")
        elif error_code in {"ACTIVE_LIMIT", "MONTHLY_LIMIT"}:
            raise ProviderException("Download limit exceeded")
        elif error_code in {"DOWNLOAD_SERVER_ERROR", "DATABASE_ERROR"}:
            raise ProviderException("Torbox server error")

    def _make_request(
        self,
        method,
        url,
        data=None,
        params=None,
        json=None,
        is_return_none=False,
        is_expected_to_fail=False,
    ):
        params = params or {}
        url = self.BASE_URL + url
        response = self._perform_request(method, url, data, params, json)
        if url.endswith("/torrents/requestdl") and response.status_code in {400, 401, 403, 404, 408, 429, 500, 502, 503, 504}:
            kodilog("[Diagnostics] http_status_" + str(response.status_code), level=xbmc.LOGINFO)
        validated_response = self._validate_error_response(response)
        if validated_response is not None:
            return validated_response
        self._handle_errors(response, is_expected_to_fail)
        return self._parse_response(response, is_return_none)

    def _validate_error_response(self, response):
        if response.ok:
            return None

        content_type = response.headers.get("Content-Type", "")
        if not content_type.startswith("application/json"):
            return None

        try:
            error_data = response.json()
        except ValueError:
            return None

        if not isinstance(error_data, dict):
            return None

        error_code = error_data.get("error", "")
        error_detail = str(error_data.get("detail", "")).lower()

        if (
            response.status_code == 400
            and error_code == "DIFF_ISSUE"
            and "already queued" in error_detail
        ):
            kodilog(
                "Torbox._validate_error_response: treating duplicate queued torrent as recoverable state"
            )
            normalized = dict(error_data)
            normalized["success"] = True
            normalized["queued"] = True
            return normalized

        return None

    def _validate_response(self, response, data_type=None):
        if not isinstance(response, dict) or not isinstance(response.get("success"), bool):
            raise ProviderException("Invalid Torbox response")
        if not response["success"]:
            self._handle_service_specific_errors(response, 200)
            raise ProviderException(response.get("detail") or "Torbox request failed")
        if data_type is not None and not isinstance(response.get("data"), data_type):
            raise ProviderException("Invalid Torbox response data")
        return response

    def _complete_torrent_add(self, response):
        from lib.db.cached import cache

        self._validate_response(response)
        if response.get("queued") is not True and not isinstance(response.get("data"), dict):
            raise ProviderException("Invalid Torbox response data")
        cache.delete(self.CLOUD_CACHE_KEY)
        return response

    def add_magnet_link(self, magnet_link):
        response = self._make_request(
            "POST",
            "/torrents/createtorrent",
            data={"magnet": magnet_link, "seed": 3, "allow_zip": "false"},
            is_expected_to_fail=False,
        )
        return self._complete_torrent_add(response)

    def add_torrent_file(self, torrent_data, torrent_name="torrent.torrent"):
        response = self.session.request(
            method="POST",
            url=f"{self.BASE_URL}/torrents/createtorrent",
            data={
                "seed": 3,
                "allow_zip": "false",
                "name": torrent_name or "torrent.torrent",
            },
            files={
                "file": (
                    torrent_name or "torrent.torrent",
                    torrent_data,
                    "application/x-bittorrent",
                )
            },
            headers=self.headers,
            timeout=self.timeout,
        )
        self._handle_errors(response, is_expected_to_fail=False)
        return self._complete_torrent_add(self._parse_response(response, is_return_none=False))

    def get_user_torrent_list(self):
        try:
            response = self._make_request(
                "GET",
                "/torrents/mylist",
                params={"bypass_cache": "true"},
            )
            self._validate_response(response, list)
            for torrent in response["data"]:
                if not isinstance(torrent, dict):
                    raise ProviderException("Invalid Torbox torrent data")
                files = torrent.get("files")
                if files is not None and (
                    not isinstance(files, list) or any(not isinstance(item, dict) for item in files)
                ):
                    raise ProviderException("Invalid Torbox torrent files")
            return response
        except ProviderException as exc:
            if "Request timed out" in str(exc):
                raise ProviderException(
                    "Torbox timed out while checking your cloud torrents. Please try again."
                ) from exc
            raise

    def get_torrent_info(self, magnet_id):
        response = self.get_user_torrent_list()
        torrent_list = response.get("data", {})
        for torrent in torrent_list:
            if torrent.get("magnet", "") == magnet_id:
                return torrent

    def get_available_torrent(self, info_hash):
        try:
            response = self.get_user_torrent_list()
        except ProviderException:
            raise
        torrent_list = response.get("data", {})
        for torrent in torrent_list:
            if torrent.get("hash", "") == info_hash:
                return torrent

    def get_torrent_instant_availability(self, torrent_hashes):
        response = self._make_request(
            "POST",
            "/torrents/checkcached",
            params={"format": "list"},
            json={"hashes": torrent_hashes},
        )
        self._validate_response(response, list)
        for item in response["data"]:
            if not isinstance(item, str) and not (
                isinstance(item, dict) and isinstance(item.get("hash"), str)
            ):
                raise ProviderException("Invalid Torbox cache data")
        return response

    def create_download_link(self, torrent_id, filename, user_ip=None):
        if torrent_id in (None, "") or filename in (None, ""):
            raise ProviderException("No TorBox file selected. Scrape again and choose a source.")
        params = {
            "token": self.token,
            "torrent_id": torrent_id,
            "file_id": filename,
        }
        if user_ip:
            try:
                params["user_ip"] = str(ipaddress.ip_address(user_ip))
            except ValueError:
                pass

        response = self._make_request(
            "GET",
            "/torrents/requestdl",
            params=params,
            is_expected_to_fail=True,
        )
        if isinstance(response, dict) and response.get("success") is True and isinstance(response.get("data"), str) and response["data"].strip():
            return response
        error = response.get("error") if isinstance(response, dict) else None
        category = {
            "BAD_TOKEN": "auth", "AUTH_ERROR": "auth", "OAUTH_VERIFICATION_ERROR": "auth",
            "DOWNLOAD_TOO_LARGE": "plan", "ACTIVE_LIMIT": "limit", "MONTHLY_LIMIT": "limit",
            "COOLDOWN_LIMIT": "limit", "DOWNLOAD_SERVER_ERROR": "server", "DATABASE_ERROR": "server",
        }.get(error if isinstance(error, str) else None, "other")
        kodilog("[Diagnostics] torbox_link_" + category, level=xbmc.LOGINFO)
        message = {
            "auth": "Reconnect TorBox in Settings > Accounts.",
            "plan": "This download exceeds your TorBox plan limit.",
            "limit": "Your TorBox download limit or cooldown has been reached.",
            "server": "TorBox is having a server problem. Please try again later.",
        }.get(category, "TorBox could not create a download link. Scrape again or choose another source.")
        notification(message)
        return None

    def delete_torrent(self, torrent_id):
        self._make_request(
            "POST",
            "/torrents/controltorrent",
            data={"torrent_id": torrent_id, "operation": "Delete"},
            is_expected_to_fail=False,
        )

    def download(self, magnet_link):
        try:
            response = self.add_magnet_link(magnet_link)
        except ProviderException:
            # ProviderException already displays the failure notification.
            return False

        if response.get("success"):
            notification(translation(90362) % "Torbox")
            return True

        notification(response.get("detail") or "Failed to add torrent to Torbox")
        return False

    def get_device_code(self):
        return self._make_request(
            "GET",
            "/user/auth/device/start",
            params={"app": "Flux Stream"},
        )

    def get_token(self, device_code, is_expected_to_fail=False):
        return self._make_request(
            "POST",
            "/user/auth/device/token",
            json={"device_code": device_code},
            is_expected_to_fail=is_expected_to_fail,
        )

    def authorize(self, device_code):
        response_data = self.get_token(device_code, is_expected_to_fail=True)
        if response_data.get("success"):
            token_data = response_data.get("data", {})
            if isinstance(token_data, dict):
                return {"token": token_data.get("access_token")}
            return {"token": token_data}
        return response_data

    def remove_auth(self):
        self.token = ""
        set_setting("torbox_token", "")
        set_setting("torbox_user", "")
        set_setting("torbox_enabled", "false")
        dialog_ok(translation(90544), translation(90561))

    def auth(self):
        run_torbox_auth(self)

    def get_user(self):
        return self._make_request("GET", "/user/me")

    def days_remaining(self):
        try:
            account_info = self.get_user()
            if not account_info.get("success"):
                return None

            data = account_info.get("data", {})
            expires_at = data.get("premium_expires_at")
            if not expires_at:
                return None

            # Try common ISO formats
            for fmt in (
                "%Y-%m-%dT%H:%M:%S.%fZ",
                "%Y-%m-%dT%H:%M:%SZ",
                "%Y-%m-%dT%H:%M:%S",
            ):
                try:
                    expires = datetime.datetime.strptime(expires_at, fmt)
                    break
                except ValueError:
                    continue
            else:
                return None

            days = (expires - datetime.datetime.utcnow()).days
            return days
        except Exception as e:
            kodilog(f"Error calculating days remaining: {e}")
            return None
