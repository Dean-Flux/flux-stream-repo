class TMDbException(Exception):
    pass
