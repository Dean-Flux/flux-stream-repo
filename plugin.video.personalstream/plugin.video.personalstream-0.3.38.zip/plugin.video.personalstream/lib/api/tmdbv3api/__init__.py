"""Load SDK endpoints when requested, keeping submodule imports lightweight."""

from importlib import import_module

_EXPORTS = {
    'Account': '.objs.account',
    'Authentication': '.objs.auth',
    'Certification': '.objs.certification',
    'Change': '.objs.change',
    'Collection': '.objs.collection',
    'Company': '.objs.company',
    'Configuration': '.objs.configuration',
    'Credit': '.objs.credit',
    'Discover': '.objs.discover',
    'Episode': '.objs.episode',
    'Find': '.objs.find',
    'Genre': '.objs.genre',
    'Group': '.objs.group',
    'Keyword': '.objs.keyword',
    'List': '.objs.list',
    'Movie': '.objs.movie',
    'Network': '.objs.network',
    'Person': '.objs.person',
    'Provider': '.objs.provider',
    'Review': '.objs.review',
    'Search': '.objs.search',
    'Season': '.objs.season',
    'Trending': '.objs.trending',
    'TV': '.objs.tv',
    'TMDb': '.tmdb',
}
__all__ = list(_EXPORTS)


def __getattr__(name):
    if name not in _EXPORTS:
        raise AttributeError("module %r has no attribute %r" % (__name__, name))
    value = getattr(import_module(_EXPORTS[name], __name__), name)
    globals()[name] = value
    return value
