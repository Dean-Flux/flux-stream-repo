"""Explicit, previewed reports using the existing private diagnostic inbox."""
import json
import re
import sys

import xbmc
import xbmcgui
from xbmcvfs import translatePath

from lib.config import CRASH_REPORT_ENDPOINT
from lib.services.crash_reporting import build_manual_report, valid_report
from lib.utils.kodi.utils import ADDON_VERSION, finish_action


def send_diagnostic_report(params=None):
    finish_action()
    dialog = xbmcgui.Dialog()
    build = re.match(r"\d+\.\d+(?:\.\d+)?", xbmc.getInfoLabel("System.BuildVersion"))
    platform = "Android" if xbmc.getCondVisibility("System.Platform.Android") else {
        "win32": "Windows", "darwin": "macOS", "linux": "Linux"
    }.get(sys.platform, "Other")
    try:
        report = build_manual_report(translatePath("special://logpath/kodi.log"), ADDON_VERSION,
                                     build[0] if build else "0.0", platform)
        if not valid_report(report):
            raise ValueError("Invalid diagnostic summary")
    except (OSError, ValueError):
        dialog.ok("Send log report", "The current Kodi log could not be read. Reproduce the problem and try again.")
        return
    dialog.textviewer("Log report preview", "This is the complete report to be sent to Dean-Flux's private inbox. "
                      "It summarizes recent log events, not the full log. No account details, titles, or streaming links.\n\n"
                      + json.dumps(report, indent=2))
    if not dialog.yesno("Send log report", "Send this diagnostic summary to Dean-Flux? "
                        "This sends once, even if automatic crash reporting is off."):
        return
    progress = xbmcgui.DialogProgressBG()
    progress.create("Flux Stream", "Sending diagnostic report...")
    try:
        import requests

        response = requests.post(CRASH_REPORT_ENDPOINT, json=report, timeout=(3, 30), allow_redirects=False)
        if response.status_code in (200, 201, 202):
            message = "Report sent. Reference: " + report["report_id"][:8] + ". Let Dean know what you selected when it failed."
        elif response.status_code == 429:
            message = "The inbox has reached its daily report limit. Please try again tomorrow."
        else:
            message = "The report could not be delivered. Please try again later."
    except Exception:
        message = "The report could not be delivered. Check your internet connection and try again later."
    finally:
        progress.close()
    dialog.ok("Send log report", message)
