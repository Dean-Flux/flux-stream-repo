"""A repeatable setup checklist using Kodi's native remote-friendly dialogs."""

import json
import os
from xml.etree import ElementTree

import xbmc
import xbmcaddon
import xbmcgui

from lib.utils.kodi.utils import (
    ADDON_ID,
    build_url,
    clear_cached_settings,
    finish_action,
    get_setting_fresh,
    kodilog,
    set_setting,
)
from lib.utils.tmdb_init import get_tmdb_api_key

COCO_ID = "script.module.cocoscrapers"
COCO_REPOSITORY = "repository.cocoscrapers"
COCO_SOURCE = "https://cocojoe2411.github.io/"


def _addon_details(addon_id):
    result = json.loads(xbmc.executeJSONRPC(json.dumps({
        "jsonrpc": "2.0", "id": 1, "method": "Addons.GetAddonDetails",
        "params": {"addonid": addon_id, "properties": ["enabled", "path"]},
    })))
    return result.get("result", {}).get("addon", {})


def setup_status():
    clear_cached_settings()
    status = {
        "torbox": bool(get_setting_fresh("torbox_token", "")),
        "trakt": bool(get_setting_fresh("is_trakt_auth", False)),
        "trakt_enabled": bool(get_setting_fresh("trakt_enabled", False)),
        "metadata": bool(get_tmdb_api_key()),
        "coco": "missing",
    }
    details = _addon_details(COCO_ID)
    if not details:
        return status
    if not details.get("enabled"):
        status["coco"] = "disabled"
        return status
    try:
        addon = xbmcaddon.Addon(COCO_ID)
        tree = ElementTree.parse(os.path.join(details["path"], "resources", "settings.xml"))
        providers = [row.get("id") for row in tree.findall(".//setting")
                     if row.get("id", "").startswith("provider.")]
        status["coco"] = "ready" if any(addon.getSetting(key) == "true" for key in providers) else "no_providers"
    except Exception:
        status["coco"] = "error"
        kodilog("Setup: unable to read CocoScrapers provider settings")
    return status


def _coco_setup(status):
    if status["coco"] == "disabled":
        response = json.loads(xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0", "id": 1, "method": "Addons.SetAddonEnabled",
            "params": {"addonid": COCO_ID, "enabled": True},
        })))
        if "error" in response:
            xbmcgui.Dialog().ok("Enable CocoScrapers", "Open Kodi > Add-ons > My add-ons and enable CocoScrapers, then return to Setup Wizard.")
    elif status["coco"] == "missing":
        repository = _addon_details(COCO_REPOSITORY)
        if repository.get("enabled") and xbmcgui.Dialog().yesno(
            "Install CocoScrapers", "Install the CocoScrapers module from its installed developer repository? Kodi will handle installation and dependencies."
        ):
            xbmc.executebuiltin("InstallAddon(script.module.cocoscrapers)", True)
        else:
            xbmcgui.Dialog().textviewer("Install CocoScrapers", (
                "CocoScrapers finds playback sources. It needs no account or API key.\n\n"
                "1. Close this wizard and open Kodi Settings > File manager > Add source.\n"
                "2. Enter " + COCO_SOURCE + " and name it CocoScrapers.\n"
                "3. Open Add-ons > Install from zip file > CocoScrapers. Install the repository ZIP.\n"
                "4. Open Install from repository > CocoScrapers Repository > Program add-ons > CocoScrapers Module > Install.\n"
                "5. Return to Flux Stream > Setup Wizard.\n\n"
                "Kodi may ask you to enable Unknown sources for the repository ZIP. Flux Stream does not change that security setting or install third-party repositories automatically."
            ))
    else:
        xbmcaddon.Addon(COCO_ID).openSettings()


def run_setup_wizard(params=None):
    finish_action()
    dialog = xbmcgui.Dialog()
    while True:
        status = setup_status()
        ready = status["torbox"] and status["coco"] == "ready" and status["metadata"]
        # Keep new preference steps here so setup remains one checklist.
        steps = [
            ("torbox", "1. TorBox - " + ("Connected" if status["torbox"] else "Connect your account"),
             "Ready for playback. Select to view connection settings." if status["torbox"] else "Required for playback. Scan the QR code and approve your own TorBox account."),
            ("coco", "2. CocoScrapers - " + {"ready": "Ready", "missing": "Install module", "disabled": "Enable module", "no_providers": "Choose providers", "error": "Check installation"}[status["coco"]],
             "Installed with providers enabled. Select to manage providers." if status["coco"] == "ready" else "Required for source searches. No account needed; select for help."),
            ("trakt", "3. Trakt (optional) - " + ("Connected" if status["trakt"] else "Connect or skip"),
             ("Watchlists and progress are enabled." if status["trakt_enabled"] else "Account connected; select to turn on Trakt features.") if status["trakt"] else "Public browsing is included. Connect for personal lists and progress; current development login requires an invitation. You can skip this."),
            ("metadata", "4. Movies and TV metadata - " + ("Included" if status["metadata"] else "Needs attention"),
             "TMDB is included. No registration or key entry needed." if status["metadata"] else "Open Metadata settings to check the optional key override."),
            ("finish", "Finish - " + ("Start browsing" if ready else "Check remaining steps"),
             "Open Movies and select a title to find sources." if ready else "TorBox, CocoScrapers, and metadata are needed for search and playback. Trakt is optional."),
        ]
        items = [xbmcgui.ListItem(label=title, label2=description) for _, title, description in steps]
        choice = dialog.select("Flux Stream Setup - " + ("Ready to watch" if ready else "Let's get you connected"), items, useDetails=True)
        if choice < 0:
            return
        action = steps[choice][0]
        try:
            if action == "torbox":
                if status["torbox"]:
                    xbmcaddon.Addon(ADDON_ID).openSettings()
                else:
                    from lib.nav.debrid import tb_auth

                    tb_auth({})
            elif action == "coco":
                _coco_setup(status)
            elif action == "trakt":
                if status["trakt"]:
                    if status["trakt_enabled"]:
                        dialog.ok("Trakt connected", "Your Trakt account is connected. Manage it in Flux Stream Settings > Accounts.")
                    else:
                        set_setting("trakt_enabled", "true")
                else:
                    from lib.api.trakt.trakt import TraktAPI

                    TraktAPI().auth.trakt_authenticate()
            elif action == "metadata":
                if status["metadata"]:
                    dialog.ok("Metadata included", "Movie and TV catalogs are ready. You do not need a TMDB account or API key.")
                else:
                    xbmcaddon.Addon(ADDON_ID).openSettings()
            elif ready:
                xbmc.executebuiltin("Container.Update({})".format(build_url("movies_items")))
                return
            else:
                dialog.ok("A few steps left", "Connect TorBox and install/enable CocoScrapers with at least one provider. Movie and TV metadata must also be available. You can skip Trakt.")
        except Exception:
            kodilog("Setup: step failed: " + action)
            dialog.ok("Setup needs attention", "That step could not finish. Try again, or open Flux Stream Settings.")
