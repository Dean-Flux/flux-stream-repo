# Flux Stream

A personal Kodi add-on foundation based on [Jacktook](https://github.com/Sam-Max/plugin.video.jacktook) by Sam-Max.

The supported configuration is TorBox for playback, CocoScrapers for discovery, Trakt for tracking, and TMDB for metadata and artwork. IMDb IDs remain part of title matching. TorBox authorization and cached playback have been confirmed on the owner's Kodi device; Trakt QR authorization still needs live confirmation.

## Identity and isolation

- Display name: Flux Stream
- Add-on ID: `plugin.video.personalstream`
- Version: `0.3.41`
- Kodi-managed profile: `special://profile/addon_data/plugin.video.personalstream/`
- Private session properties use the `personalstream` namespace.
- The upstream updater, installation helper, automatic TMDBHelper writes, donation prompt, and unrelated background services have been removed from the active flow.
- No existing Jacktook account settings or databases are migrated or modified.

## Setup

1. Use Kodi 21 as the initial development target. Other versions and playback hardware still need validation.
2. Install and enable `script.module.cocoscrapers` separately from its developer's repository. This build does not install third-party repositories automatically.
3. Install the Flux Stream ZIP using Kodi's Install from zip file action.
4. Under Settings > Accounts, authorize TorBox.
5. TMDB metadata is included through Flux Stream's registered application key. No TMDB account or key entry is needed. An optional personal key override remains available at Expert level under Metadata.
6. For Trakt, choose Accounts > Connect Trakt (QR code), scan the displayed QR code, enter the short activation code if prompted, and approve Flux Stream. Its public development-app Client ID is bundled; a client secret is not required. Tracking enables after successful authorization and background sync waits for the initial connection. Optional developer overrides are available only at Expert settings level.

Sources are cached-only. Manual source selection is the default. Retired integrations are disabled by runtime settings even if an imported profile contains old flags. Their code remains where shared imports still require it; this is a narrowed foundation, not a completed removal of every unused module.

Continue Watching separates local progress and Trakt progress. Combining those feeds and reconciling offline conflicts is later work. Scraper searches have a configurable 20-second default deadline. Timeout returns completed sources without caching the incomplete search. Cancel stops the flow before filtering, cache checks, or playback. At most eight daemon provider workers may be outstanding in one interpreter; queued work stops on timeout/cancel and late results are discarded. Python cannot forcibly interrupt a blocked third-party network call, so a busy worker may remain until its provider returns. Both legacy search presentation settings use the same native cancelable progress dialog.

## Local Windows development

From this checkout in PowerShell, use an isolated environment:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-test.txt
.\.venv\Scripts\python.exe -m pytest tests/unit/test_personalstream_foundation.py tests/unit/test_settings_xml.py tests/unit/test_updater.py
.\.venv\Scripts\python.exe package.py
```

The package is written to `dist/plugin.video.personalstream-0.3.41.zip`. Use `python package.py --output <directory>` to choose another destination. Tests, development configuration, caches, the original player-helper ZIP, and repository metadata are excluded. The ZIP contains the required `plugin.video.personalstream/` top-level folder.

## Manual reports and startup checks 0.3.30

Settings > Maintenance > Send log report previews a fixed diagnostic summary from the recent tail of the current Kodi log, then asks before sending it to the existing private inbox. Manual reports work even if automatic crash reporting is off and do not use its six-hour cooldown. They share the receiver's daily cap. No raw log, credentials, titles, or media URLs are uploaded. Playback resolution now logs fixed provider, outcome, and selected HTTP status events at normal log level.

After the startup reporting grace period, the service waits another 45 seconds before asking Kodi to check enabled repositories once per Kodi session. It waits while playback is active, honors disabled global updates, and leaves installation to Kodi's global update mode and each add-on's Auto-update switch. It does not install ZIPs itself or restore the upstream updater.

## Lighter home metadata 0.3.29

Trakt title listings and Continue Watching request basic details plus images and external IDs, avoiding trailers, credits, and translations during widget population. These summaries use separate persistent TMDB cache entries with the existing expiration policy. Full detail requests remain available for playback and detail views. Artwork rendering uses the existing settings snapshot instead of reparsing settings.xml per poster.

A live payload sample was 89% smaller for Ocean's Eleven and 57% smaller for The Office; these are response-size comparisons, not measured Shield startup improvements.

## Default browsing views 0.3.28

Movies and TV shows default to Info Wall in Flux Stream and Estuary. Seasons and episodes default to List. Explicit saved view choices take precedence; defaults are not written into the profile. Other skins keep their own defaults. The movie-only In Progress feed advertises movie content so it supports Info Wall too.

## Related title results 0.3.27

See similar uses TMDB Recommendations for closer title relationships, instead of the broad genre/keyword Similar feed. The menu stays unchanged and uses one list request per page.

## Home widget navigation 0.3.26

See Collection and See similar explicitly open the Videos window, so both actions work from home-screen widgets as well as add-on directories.

## Simple context menus 0.3.25

Movies offer Scrape again, Source Select, Mark watched on Trakt, Mark unwatched on Trakt, See Collection, and See similar. Trakt actions appear when connected. TV shows and seasons keep watched/unwatched and similar-show actions; individual episodes also offer scraping and source selection. In Progress uses the same menu while preserving resume data. See Collection resolves the movie's TMDB series on demand and lists its films in release order; standalone movies show a notice. No extra metadata requests are made while building context menus.

## Crash reporting 0.3.24

Send crash reports is on by default and can be switched off in Settings > Maintenance > Privacy and diagnostics, or in step 7 of the setup wizard. After an unexpected shutdown, the next startup sends a limited diagnostic summary privately to Dean-Flux. Clean shutdowns, first installs, and sessions with reporting off do not generate reports. Power loss or forced closure can also count as an unexpected shutdown.

Only application/Kodi versions, platform family, session/detection timestamps, selected fixed event names, error types, and relative Flux Stream code locations are allowed. Raw logs, account identities, tokens, media titles, paths outside Flux Stream code, and streaming URLs are not uploaded. The receiver rejects unknown fields and arbitrary text.

The personal Vercel receiver writes private GitHub issues in `Dean-Flux/flux-stream-reports` using a repository-restricted GitHub App. Its key stays server-side. Nothing is hosted under Lesser Media. No package dependencies or extra family-device apps are required. GitHub email notifications follow the owner's settings.

Delivery is attempted once per startup after a 15-second grace period, with a six-hour cooldown after success. One unsent report can retry on a later launch for seven days after detection. Turning the setting off deletes unsent data and prevents new sends; it cannot recall a request already in progress or a report already received. Local marker and queue files stay inside Flux Stream's own profile.

## Stability update 0.3.23

- Failed direct-video startup exits through player cleanup after 15 seconds without an active loading dialog or buffering; media already opened gets an additional 30-second decoding grace period.
- Trakt watched/progress replacements use a single transaction with SQLite journaling. Routine refreshes no longer compact the database.
- Debrid availability checks support cancellation and shutdown, with a 40-second overall deadline. Running HTTP requests finish within provider timeouts; abandoned results cannot update the source list or Kodi dialog.
- TV widgets share a two-minute account-scoped watched-show snapshot across interpreters. Successful watched-history changes and completed scrobbles invalidate it; background watched sync refreshes it.
- Skin helper 1.0.3 fetches optional OMDb ratings serially with network timeouts and a 60-second failure retry delay. Database connections close after each fetch, and changed selections do not receive old ratings.
- Interpreter reuse remains disabled. No automatic log uploads are included.

The larger upstream suite has test isolation/mock failures in a combined Windows run, observed before this fork changed the code. Run relevant integration groups separately and distinguish these baseline failures from regressions.

## Attribution and licensing

Original Jacktook source snapshot: `cb3bd2d2dc08dd35a98aabc668f319e31137fff9`.

Original copyright notices and the upstream LICENSE are retained. Upstream LICENSE contains GPL version 3, while addon.xml declares GPL-2.0-only. This discrepancy is unresolved; clarify it before distributing a derivative. Flux Stream icon, fanart, and clearlogo use original retro-futurist artwork; remaining interface glyphs retain upstream attribution.

TMDB attribution: This product uses the TMDB API but is not endorsed or certified by TMDB. Settings > Metadata > About / Credits displays the included TMDB logo and required notice.

Validate Trakt account authorization, CocoScrapers compatibility, movie and episode playback, seeking/resume, and Trakt progress on the target device before treating the build as ready for use.


## Search controls and filters

Movies and individual TV episodes retain their Scrape again and Source Select context-menu actions. Scrape again bypasses cached search results and the quick-play shortcut. Source Select forces the manual chooser even when autoplay is enabled.

Settings > Sources controls the scraper deadline, from 5 to 120 seconds. Cancel stops the search; a timeout can still show sources completed before the deadline. A timeout does not write partial results as a complete cached search.

Settings > Filtering includes minimum/maximum reported release sizes in MiB, literal case-insensitive name filters, allowed containers, codec preferences, and HDR preferences. Required name terms are comma-separated and all must occur; any excluded term removes a release. Blank fields disable those filters. Unknown source sizes are retained. Season-pack sizes are reported release sizes, not per-episode sizes.

Allowed containers can be entered as `mkv, mp4` or `.mkv, .mp4`. A release with no identifiable container can remain in the source list; the actual TorBox filename is checked before generating a playback link, including cloud and pack playback. File-type filtering does not change the underlying codec.

Settings > Home menu lets you hide optional sections, choose Continue Watching/Movies/TV Shows as the first visible section, and open Kodi's existing section-view chooser. Settings remains available even when every optional section is hidden. View availability depends on the active Kodi skin.


## Version 0.2.2 label fix

Settings categories, groups, fields, and option labels now use numeric localization IDs backed by English strings. This corrects blank labels caused by literal text in the version-1 settings schema. Install the updated ZIP and restart Kodi; no profile reset is needed.


## Version 0.2.3 Trakt QR connection

Flux Stream is registered as a Trakt Development application owned by the developer account used for this personal build. The bundled Client ID is public application identity, not a user access token or client secret. Only the owner and explicitly invited development testers can authorize this app; it is not a production-wide registration.

Trakt no longer requires a client secret for this device flow. The app omits the secret from device-token, refresh, and revoke requests when none is configured, while retaining compatibility with explicit legacy credentials. Optional credential overrides have valid empty defaults and are kept at Expert level. Successful login enables Trakt tracking. The sync service waits for first authorization rather than exiting at startup.

The QR uses Trakt's verification URL, or its complete verification URL when one is provided. Trakt may still ask you to enter the short code displayed beside the QR before approval. No Trakt password is entered into Flux Stream.

The corrected build retains the same add-on ID/profile. Install the ZIP over the previous build; do not reset settings or remove the profile. Real device-code creation was accepted by Trakt. Full user authorization, token receipt, and synchronization still need confirmation in Kodi.

## GitHub releases and updates

Development source is maintained in the private [Dean-Flux/flux-stream](https://github.com/Dean-Flux/flux-stream) repository. Public Kodi packages and their complete packaged Python source are hosted in [Dean-Flux/flux-stream-repo](https://github.com/Dean-Flux/flux-stream-repo).

Add `https://dean-flux.github.io/flux-stream-repo/` to Kodi's File manager, install `repository.fluxstream-1.0.0.zip` from that source, then use Install from repository > Flux Stream Repository > Video add-ons > Flux Stream. For an existing manual installation, choose Update or Versions in its information screen and select the Flux Stream Repository build once to associate it with that repository. Leave Auto-update enabled.

Future higher-version builds published to this repository can update through Kodi's add-on manager. The original upstream self-updater remains disabled. Kodi preserves the existing add-on profile because the add-on ID is unchanged. CocoScrapers must still be installed separately from its developer's repository.

To publish an update: bump the add-on version, build with `python package.py`, run `python publish.py <path-to-built-zip>` in the sibling `flux-stream-repo` checkout, review and push the distribution changes. The publisher regenerates the catalog, checksum, and package links. GitHub Pages deploys the updated files. Never replace a published package with different contents under the same version.

## Version 0.2.5 account settings persistence

TorBox and Trakt connection/disconnection buttons close the settings dialog before running. Kodi otherwise routes Python setting writes into the open dialog instead of saving the profile directly; closing or canceling that dialog can lose the account fields despite a successful authorization. After updating, restart Kodi, reconnect from Accounts, and reopen settings to see the saved user and Trakt enabled state. Existing progress and other settings are preserved.

## Version 0.2.6 visible account status

Each account now shows Status: Connected or Status: Not connected. TorBox uses the saved token; Trakt uses the authenticated-account flag. Connect appears only when disconnected; Disconnect and the account field appear only when connected. Use Trakt controls whether Trakt features run and is separate from authorization. These indicators reflect saved authorization, not a live service-health check. The settings-close persistence fix remains in place.

## Version 0.2.7 included TMDB metadata

The owner registered a free personal-use TMDB application and approved bundling its v3 key in public Kodi packages. Fresh profiles and blank overrides use that application key for catalog browsing, title search, and preloading. Optional personal overrides take precedence and remain at Expert settings level. The TMDB read-access bearer token and account credentials are not bundled.

Metadata settings include an About / Credits dialog with the included logo and attribution notice. Live movie and TV catalog requests returned results with the registered application key. CocoScrapers still requires a separate installation; TorBox and Trakt use each family member's own account. The Trakt app remains in Development mode, so family accounts must first be added as invited testers.

## Trakt notice and privacy

Flux Stream uses Trakt but is not endorsed or certified by Trakt.

[Privacy policy](https://dean-flux.github.io/flux-stream-repo/privacy.html) | [Application details and credits](https://dean-flux.github.io/flux-stream-repo/about.html)

Version 0.2.8 adds the Trakt notice to the existing in-app About / Credits dialog. Production access is being requested; no production Client ID has been issued or bundled. Development authorization rules stay in effect until Trakt grants access and a later build includes its production Client ID.

## Version 0.2.9 family setup and browsing

Setup Wizard is always available from the main menu, even when optional home sections are hidden. It checks saved TorBox/Trakt authorization, whether Trakt features are enabled, the installed/enabled CocoScrapers module and its provider toggles, and included TMDB metadata. It reuses the existing QR account connections and refreshes the checklist after each step. Already connected accounts are not reauthorized. Trakt is optional for playback. These are local readiness checks, not online account-health or provider-availability tests.

For missing CocoScrapers, the wizard offers the developer repository installation instructions. If its repository is already installed and enabled, the wizard can ask Kodi to install the module with normal installation prompts. Disabled modules can be enabled by selecting their setup step; installed modules open their settings for provider selection. Flux Stream does not install a third-party repository or change Unknown sources automatically. Back exits safely; selecting Finish opens Movies only when the required local checks pass. New preference steps such as autoplay can be added to the checklist later; this release does not change playback preferences.

Movies adds Top Rated, New Releases (In Theaters), and Upcoming (In Theaters). TV Shows adds Top Rated, Airing Today, and On the Air. The new folders use TMDB without Trakt login and retain normal source selection, metadata, and pagination. The movie release folders describe theatrical schedules rather than guaranteed streaming availability.

## Version 0.3.0 built-in Trakt browsing

Movies and TV Shows now open Trakt discovery directly: Trending, Popular, Most Watched, Popular Lists, Trending Lists, Search Lists, My Lists, Liked Lists, My Watchlist, and Recommendations. The registered application Client ID is included. Public discovery and community lists work without account sign-in or developer-key entry; live unauthenticated requests were verified. Personal folders explain how to connect through Setup Wizard or enable Use Trakt when needed. No personal credentials are included in packages.

Browse TMDB remains a submenu with the expanded TMDB categories. TMDB metadata and artwork remain included through the registered application key. Existing source selection and playback routes are reused. Public Trakt list links now retain their numeric IDs so lists without owner slugs can open correctly. Popular title results retain pagination and use the existing TMDB enrichment/playback renderer.

Only invitation-free personal Trakt login depends on pending Production access. Public browsing does not require the family member to be an invited tester. Focused Trakt and metadata/wizard test groups are verified separately because combined Kodi mocks can interfere with each other.

## Version 0.3.1 neutral menu icons

Trakt-backed browsing folders now use the existing movie/TV icons. Other Trakt menu entries use neutral category/progress artwork instead of the Trakt logo. Trakt data sources and required credits stay in place.

## Version 0.3.2 Flux Stream branding

Original retro-futurist artwork replaces the inherited Jacktook app icon, browsing background, resolver fallback background, and source-selection clearlogos. The palette is midnight navy, orange, amber, teal, and warm ivory with a signal-ribbon/orbital mark. The icon is 512 x 512, fanart is 1920 x 1080, and the overlay wordmark has a cleaned transparent alpha channel. Artwork-specific file names prevent Kodi from reusing cached upstream art. Old upstream promotional screenshots are no longer advertised in the manifest. Original code attribution and service credits remain intact.

## Version 0.3.3 matching menu icons

Original mission-style menu badges use Flux Stream's midnight navy, ivory, orange, amber, and teal palette. Main navigation, discovery folders, lists, pagination, and utility menus share the set. Movies and TV have distinct Trending, Popular, Most Watched, Lists, Watchlist, and Recommendations symbols; the Setup Wizard has its own badge. TMDB's official credit artwork remains intact. Icons are rendered by the development-only `scripts/generate_menu_icons.py`; Kodi needs no additional dependency.

## Version 0.3.4 My Trakt

The main menu adds My Trakt with In Progress, Watch History, Watchlist, My Lists, Liked Lists, Collection, Favorites, and Recommendations. Each category splits into Movies and TV Shows. Movie progress uses the existing Trakt resume flow, preserving playback IDs and resume positions; TV progress shows resumed/next unwatched episodes of started series using the existing Up Next feed. Personal feeds require a connected, enabled Trakt account. Dashboard settings can hide My Trakt or make it the first section. Existing Continue Watching, Watchlist, public discovery, and profile data remain available.

## Version 0.3.5 TV pack discovery

CocoScrapers now checks full-series packs as well as episodes and single-season packs, using the TMDB season count and the existing scraper deadline/cancellation. Pack mapping rejects show packs that end before the requested season and partial-season packs missing the requested episode. Validated pack-season metadata preserves matching packs through episode filtering. Old incomplete search caches are bypassed. Empty cached-only searches now explain that no TorBox cached sources survived filtering; actual availability still depends on the enabled providers and TorBox cache.

## Version 0.3.6 Trakt series progress

My Trakt > In Progress > TV Shows now lists started series with unwatched aired episodes, including shows between episodes and paused-only shows. Watch History > Completed TV Shows lists series caught up through every regular aired episode. Both open show seasons rather than an episode search. Specials and repeat plays do not inflate completion; reset progress is respected, and hidden progress shows stay hidden. A returning show can move back to In Progress when a new episode airs. Movie progress/history and the separate episode-resume view remain unchanged. Watched-show requests now use Trakt's extended=progress response and load all pages.

## Version 0.3.7 episode watched indicators

Episode rows now pass the parent show TMDB ID and season/episode numbers to the existing Trakt watched/resume lookup. Episode metadata is copied so cached TMDB details and episode IDs remain intact. This restores Kodi watched marks and resume indicators for tracked episodes without changing Trakt records.

## Version 0.3.8 series watched counts

My Trakt In Progress and Completed TV Shows display watched/total aired regular episodes beside each show title (for example, 22/100 watched). Counts reuse the progress classification, excluding specials and duplicate watches and respecting progress resets. Unknown totals display a question mark. Show titles, metadata, and season links remain canonical.

## Version 0.3.9 completed season marks

Season folders receive Kodi's watched checkmark when every currently aired regular episode in that season appears in the local Trakt watched cache. Future episodes do not block the mark. Empty seasons, specials, unknown air dates, or unavailable metadata are not marked completed. Seasons with no watched episodes skip metadata requests. Both routed and direct season/episode directories refresh dynamic watched indicators on reentry. Includes the series watched counts from 0.3.8.

## Version 0.3.10 poster progress indicators

TV posters publish Kodi's WatchedEpisodes, TotalEpisodes, and UnWatchedEpisodes properties, plus the completed-show play count. Trakt progress/completed feeds pass their precise counts to the shared metadata renderer; other TV rows use the watched cache and available TMDB totals. Current Trakt resume rows clear prior-watch overlays and apply their active resume position, preserving both rewatch progress and historical watched records. The skin's existing hover-count and checkmark controls are reused.

## Version 0.3.11 title aliases and compact sources

Default TV searches pass TMDB's official US/GB alternate titles to CocoScrapers, preserving regional release names such as The Office (US) without disabling title or language filters. Existing incomplete search caches are bypassed. Debrid result caches are scoped to the current candidate set so an older small result list cannot hide newly discovered sources. Source cards use 110-pixel rows instead of 220, fitting eight results at 1080p with title, quality, TorBox, codec/audio, size, provider, seeds, pack and cached status. Existing filters, source actions, and cache-only playback are retained. Provider outages still limit discovery.

## Version 0.3.12 straight source rows

Compact source rows use solid rectangular backgrounds and matching quality panels, avoiding distortion from stretched rounded textures. The PACK label has more room so it remains readable.

## Version 0.3.13 source display order

Source selection always groups resolution from 4K down to 480p, with unknown resolution last. Files are ordered largest first within each group using numeric byte sizes. Sorting also applies to cached and filtered lists, and selection follows the displayed order.

## Version 0.3.14 family skin

Flux Stream Skin and its separate helper are installed as dependencies from the same repository. Setup Wizard step 5 switches to the family home screen; confirm Kodi's Keep changes prompt. Defaults include Movies, TV Shows, In Progress, and Add-ons, with the saved family widget paths. Search uses Flux Stream's combined movie/TV search. Defaults apply once per profile; existing Umbrestuary settings are untouched. No account credentials or search history are included.

## Version 0.3.15 poster search

The family skin opens a dedicated two-row search screen with separate Movies and TV Shows poster rows, focused-title details, New search, and empty-result messages. Typed searches use separate TMDB endpoints, clean widget titles, and query-preserving pagination. Existing combined search remains available inside the add-on. Skin/helper 1.0.1 are required.

## Version 0.3.16 Real-Debrid backup

Accounts settings expose Real-Debrid QR login, connection status, disconnect, and Show Real-Debrid sources. Successful login enables results; disabling visibility keeps credentials and excludes RD from new checks/results. TorBox uses green badges and RD red. Source order remains resolution then size, with TorBox first on ties and first for autoplay. RD matches already downloaded in the account show Cached; other candidates show Check on play and may need downloading after selection. The public RD API has no general availability endpoint; TorBox cache flags are never reused as RD confirmation. Account changes invalidate RD caches, and pack caches are separate from TorBox. Reaching RD's active torrent limit reports an error instead of deleting existing torrents. The setup checklist includes an optional RD step.

## Version 0.3.17 provider visibility

Accounts settings include Show TorBox sources and Show Real-Debrid sources. Disabling either hides that provider on subsequent searches without clearing its login. The setup checklist accepts either connected, enabled provider and identifies hidden TorBox sources.

## Version 0.3.18 explicit movie source selection

Trakt movie browsing, widgets, collections, and history include Source Select and Rescrape actions. Continue Watching includes both actions while retaining the Trakt resume session. Source Select can reuse search caches; Rescrape requests fresh results. Every rescrape bypasses autoplay and opens the source picker.

## Version 0.3.19 combined debrid setup

Setup Wizard has one Debrid setup step with TorBox and Real-Debrid choices. Either or both providers can be connected; connected accounts open account/source visibility settings, and disconnected accounts start QR authorization. Hidden sources are identified separately from disconnected accounts. Neither provider is described as a backup.

## Version 0.3.20 playback preferences

Setup Wizard step 5 configures audio language, subtitle language, subtitle behavior (keep current/off/on/forced only), choose-source versus autoplay, maximum resolution, and the next-episode prompt. Skin setup is step 6. These are Flux Stream settings, not global Kodi changes. The same language and subtitle controls are available under Playback settings. Existing behavior is preserved until preferences are selected. Audio falls back to the current stream when the preferred language is absent; preferred subtitles use available tracks and stay off if no matching track exists. Manual subtitle selection is retained. A resolution cap also excludes unknown-resolution sources and bypasses saved quick-play shortcuts so cached sources cannot evade the cap.

TorBox link failures now record fixed failure categories and HTTP status codes in diagnostic reports. Invalid public-IP lookup results are omitted so TorBox can choose a CDN automatically. Empty or malformed link responses are rejected before playback.

Version 0.3.32 fixes detected season/series packs being sent to the selected-file resolver without file IDs. These releases now use normal episode matching; explicit file selections are preserved. TorBox input errors use readable messages.


### Play Next behavior (0.3.33)

Play Next appears with 120 seconds left by default (updated in 0.3.38). Settings > Playback exposes the lead time. The popup follows the video's remaining time, including pauses, and stays until playback ends. Play Next skips ahead explicitly; Keep Watching or Back cancels continuation for the current episode. Automatic continuation waits for Kodi's natural-end callback, never a separate popup timeout. Stop, playback errors, shutdown, and replacement playback do not advance.

Next-episode playback checks cached show/season/episode identity and discards inherited next-episode targets. When a search is required, it finishes before the player drains its next-episode queue. Autoplay still controls whether Flux Stream chooses a source or opens source selection. No account settings are changed.


### Trakt sign-in and startup (0.3.34)

QR images use URL-specific filenames so Kodi does not reuse another service's cached image. Codes have a solid white quiet zone, a larger display, and Trakt's documented activation-code link when the server omits a complete URL. Manual URL/code entry remains available.

Startup checks Trakt activity changes instead of forcing an unchanged watched/progress rebuild. Trakt browsing rows route directly to the existing Trakt client and avoid importing full playback navigation. Cold metadata/artwork still needs network access; measure Home loading on the Shield after installing rather than assuming a device-level speedup. Existing menus, rows, account settings, and per-profile defaults are preserved.


### Home row status reads and diagnostics (0.3.35)

Each Trakt browsing row shares one watched/resume database snapshot across its poster workers, instead of opening a connection for each status lookup. The snapshot closes before rendering, refreshes for the next row, and falls back to individual reads if unavailable. All Home sections still preload; the layout and row contents are unchanged.

Manual diagnostic reports now include fixed timing ranges for Python startup, feed fetching, and row rendering. They contain no titles, account details, or raw log text. PC profiling confirmed fewer database reads but only a small overall timing difference; Shield startup time still needs device testing.


### Lighter Home startup (0.3.36)

Home browsing defers torrent parsing, source filters, QR generation, optional artwork providers, and legacy history loading until those features are used. The bundled TMDB SDK loads package exports on demand. The fresh-process import check loads 48 fewer modules than 0.3.35.

Cache construction no longer performs a full expired-row cleanup on every invocation; individual reads still reject expired entries, and periodic or explicit cleanup remains available. All sections continue to preload. Interpreter reuse stays disabled, and each Kodi profile keeps its own account settings and cache. Actual Shield startup timing needs a device retest.


### Most recent Trakt progress first (0.3.37)

In Progress Movies explicitly sorts by the latest paused playback time. In Progress TV Shows sorts by the newest completed watch or pause, comparing actual timestamps across time zones. The same ordering feeds the default Home rows.

Progress posters still build in parallel, then publish as one ordered batch so metadata completion order cannot shuffle titles. The shared completed-series renderer also preserves its existing activity order. Movie progress directories refresh on reentry. Account settings, profile separation, and playback behavior are unchanged.


### Two-minute Play Next prompt (0.3.38)

Play Next now appears two minutes before the episode ends by default. On the first playback after updating, each profile still using the old 50-second default moves to 120 seconds; other custom lead times are preserved. Settings > Playback can adjust the lead time. The popup follows video time, pauses with playback, and waits for the natural end before automatic continuation. Explicit Play Next still skips ahead immediately.


### Final-chapter Play Next trigger (0.3.39)

On Kodi 21 and newer, Play Next also appears when a TV episode enters its final chapter, if that happens before the configured time trigger (two minutes by default). It reads Kodi Player.Chapter and Player.ChapterCount; files without usable chapters or with only one chapter keep the existing time trigger. Existing first-half and overlapping skip-dialog guards still apply. No network calls or new dependencies are added.

The final chapter is a file marker and is not guaranteed to be credits. The popup still waits for the natural end before automatic continuation; only explicitly selecting Play Next skips ahead. Chapter-triggered playback needs a Shield retest.


### Real-Debrid authorization checks (0.3.40)

Connecting verifies account and torrent-list access before saving authorization. Disconnect and reconnect work without refreshing the previous token. If Real-Debrid returns 401 during a source check, Flux Stream shows an authorization message and keeps sources from other providers when available.


### Real-Debrid QR authorization (0.3.41)

QR setup verifies the account and source endpoint with the initial access token. Pending approval can return an empty response. Unreadable Real-Debrid replies identify the failed step and HTTP status.
