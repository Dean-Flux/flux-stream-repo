from lib.utils.kodi.utils import get_setting, translation
from lib.utils.views.nuvio_collections import has_nuvio_collections
from lib.utils.views.nuvio_continue_watching import has_nuvio_continue_watching_items
from lib.utils.views.nuvio_history import has_nuvio_history_items
from lib.utils.views.nuvio_library import has_nuvio_library_items
from lib.utils.views.simkl_continue_watching import has_simkl_continue_watching_items

trakt_tv_library_items = [
    {
        "name": translation(90035),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_watchlist",
        "icon": "trakt.png",
    },
    {
        "name": translation(90294),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_collection",
        "icon": "trakt.png",
    },
    {
        "name": translation(90295),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_favorites",
        "icon": "trakt.png",
    },
    {
        "name": translation(90296),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_up_next",
        "icon": "trakt.png",
    },
    {
        "name": translation(90034),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_watched_history",
        "icon": "trakt.png",
    },
    {
        "name": translation(90297),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_my_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90298),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_liked_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90033),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_recommendations",
        "icon": "trakt.png",
    },
    {
        "name": translation(30896),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_calendar",
        "icon": "trakt.png",
    },
    {
        "name": translation(30916),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_account_info",
        "icon": "trakt.png",
    },
]


trakt_tv_discovery_items = [
    {
        "name": translation(90028),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_trending",
        "icon": "trakt.png",
    },
    {
        "name": translation(90029),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_watched",
        "icon": "trakt.png",
    },
    {
        "name": translation(90030),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_favorited",
        "icon": "trakt.png",
    },
    {
        "name": translation(90076),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_search_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90032),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_trending_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90031),
        "mode": "tv",
        "api": "trakt",
        "query": "trakt_popular_lists",
        "icon": "trakt.png",
    },
]


trakt_movie_library_items = [
    {
        "name": translation(90035),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_watchlist",
        "icon": "trakt.png",
    },
    {
        "name": translation(90294),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_collection",
        "icon": "trakt.png",
    },
    {
        "name": translation(90295),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_favorites",
        "icon": "trakt.png",
    },
    {
        "name": translation(90200),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_movies_progress",
        "icon": "trakt.png",
    },
    {
        "name": translation(90034),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_watched_history",
        "icon": "trakt.png",
    },
    {
        "name": translation(90297),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_my_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90298),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_liked_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90033),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_recommendations",
        "icon": "trakt.png",
    },
    {
        "name": translation(30916),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_account_info",
        "icon": "trakt.png",
    },
]


trakt_movie_discovery_items = [
    {
        "name": translation(90028),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_trending",
        "icon": "trakt.png",
    },
    {
        "name": translation(90036),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_top10",
        "icon": "trakt.png",
    },
    {
        "name": translation(90029),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_watched",
        "icon": "trakt.png",
    },
    {
        "name": translation(90030),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_favorited",
        "icon": "trakt.png",
    },
    {
        "name": translation(90076),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_search_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90032),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_trending_lists",
        "icon": "trakt.png",
    },
    {
        "name": translation(90031),
        "mode": "movies",
        "api": "trakt",
        "query": "trakt_popular_lists",
        "icon": "trakt.png",
    },
]


tv_items = [
    {"name": "Trending", "mode": "tv", "api": "tmdb", "query": "tmdb_trending", "icon": "tmdb.png"},
    {"name": "Popular", "mode": "tv", "api": "tmdb", "query": "tmdb_popular", "icon": "tmdb.png"},
    {'name': 'Top Rated', 'mode': 'tv', 'api': 'tmdb', 'query': 'tmdb_top_rated', 'icon': 'tmdb.png'},
    {'name': 'Airing Today', 'mode': 'tv', 'api': 'tmdb', 'query': 'tmdb_airing_today', 'icon': 'tmdb.png'},
    {'name': 'On the Air', 'mode': 'tv', 'api': 'tmdb', 'query': 'tmdb_on_the_air', 'icon': 'tmdb.png'},
    {"name": "Genres", "mode": "tv", "api": "tmdb", "query": "tmdb_genres", "icon": "tmdb.png"},
]


movie_items = [
    {"name": "Trending", "mode": "movies", "api": "tmdb", "query": "tmdb_trending", "icon": "tmdb.png"},
    {"name": "Popular", "mode": "movies", "api": "tmdb", "query": "tmdb_popular", "icon": "tmdb.png"},
    {'name': 'Top Rated', 'mode': 'movies', 'api': 'tmdb', 'query': 'tmdb_top_rated', 'icon': 'tmdb.png'},
    {'name': 'New Releases (In Theaters)', 'mode': 'movies', 'api': 'tmdb', 'query': 'tmdb_now_playing', 'icon': 'tmdb.png'},
    {'name': 'Upcoming (In Theaters)', 'mode': 'movies', 'api': 'tmdb', 'query': 'tmdb_upcoming', 'icon': 'tmdb.png'},
    {"name": "Genres", "mode": "movies", "api": "tmdb", "query": "tmdb_genres", "icon": "tmdb.png"},
]


anime_items = [
    {
        "name": translation(90006),
        "mode": "anime",
        "category": "Anime_Search",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90037),
        "mode": "anime",
        "category": "Anime_Popular",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90038),
        "mode": "anime",
        "category": "Anime_Popular_Recent",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90039),
        "mode": "anime",
        "category": "Anime_On_The_Air",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90042),
        "mode": "anime",
        "category": "Anime_Top_Rated",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90040),
        "mode": "anime",
        "category": "Anime_Years",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90041),
        "mode": "anime",
        "category": "Anime_Genres",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90028),
        "mode": "anime",
        "category": "Anime_Trending",
        "api": "trakt",
        "icon": "trakt.png",
    },
    {
        "name": translation(90154),
        "mode": "anime",
        "category": "Anime_Trending_Recent",
        "api": "trakt",
        "icon": "trakt.png",
    },
    {
        "name": translation(90043),
        "mode": "anime",
        "category": "Anime_Most_Watched",
        "api": "trakt",
        "icon": "trakt.png",
    },
    {
        "name": translation(90030),
        "mode": "anime",
        "category": "Anime_Favorited",
        "api": "trakt",
        "icon": "trakt.png",
    },
]

animation_items = [
    {
        "name": translation(90496),
        "mode": "cartoon",
        "category": "Cartoons_Popular",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
    {
        "name": translation(90497),
        "mode": "animation",
        "category": "Animation_Popular",
        "api": "tmdb",
        "icon": "tmdb.png",
    },
]

root_menu_items = [
    {"name": "Continue Watching", "icon": "continue_watching.png", "action": "personal_continue_watching"},
    {"name": "Watchlist", "icon": "trakt.png", "action": "personal_watchlist"},
    {"name": "Movies", "icon": "movies.png", "action": "movies_items"},
    {"name": "TV Shows", "icon": "tv.png", "action": "tv_shows_items"},
    {"name": "Search", "icon": "search.png", "action": "search_menu"},
    {"name": "TorBox Cloud", "icon": "cloud2.png", "action": "get_tb_downloads"},
    {"name": "Setup Wizard", "icon": "settings.png", "action": "setup_wizard", "is_folder": False},
    {"name": "Settings", "icon": "settings.png", "action": "settings"},
]

history_menu_items = [
    {"name": 90019, "icon": "history.png", "action": "files_history"},
    {"name": 90020, "icon": "history.png", "action": "titles_history"},
    {"name": 90021, "icon": "history.png", "action": "titles_calendar"},
]

nuvio_menu_items = [
    {
        "name": 90200,
        "icon": "continue_watching.png",
        "action": "nuvio_continue_watching",
        "condition": has_nuvio_continue_watching_items,
    },
    {
        "name": 90017,
        "icon": "history.png",
        "action": "nuvio_history",
        "condition": has_nuvio_history_items,
    },
    {
        "name": 91032,
        "icon": "movies.png",
        "action": "nuvio_library",
        "params": {"mode": "movies"},
        "condition": has_nuvio_library_items,
    },
    {
        "name": 91033,
        "icon": "tv.png",
        "action": "nuvio_library",
        "params": {"mode": "tv"},
        "condition": has_nuvio_library_items,
    },
    {
        "name": 91051,
        "icon": "movies.png",
        "action": "nuvio_collections",
        "condition": has_nuvio_collections,
    },
]

library_menu_items = [
    {
        "name": 90202,
        "icon": "tv.png",
        "action": "library_shows",
        "context_menu": [{"label": 90690, "action": "library_shows", "params": {"clear": 1}}],
    },  # My Shows
    {
        "name": 90203,
        "icon": "movies.png",
        "action": "library_movies",
        "context_menu": [{"label": 90690, "action": "library_movies", "params": {"clear": 1}}],
    },  # My Movies
    {
        "name": 90021,
        "icon": "history.png",
        "action": "library_calendar",
    },  # Upcoming Episodes
]
