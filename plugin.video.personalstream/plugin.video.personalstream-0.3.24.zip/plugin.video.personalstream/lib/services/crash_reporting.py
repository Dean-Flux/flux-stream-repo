"""Bounded, private diagnostics after an unclean service shutdown; no raw log upload."""

import json
import re
from pathlib import Path
from time import time
from uuid import uuid4
from datetime import datetime

MAX_LOG_BYTES = 128 * 1024
MAX_AGE_SECONDS = 7 * 86400
SEND_INTERVAL_SECONDS = 6 * 3600
ERROR_TYPES = {
    "AttributeError", "NameError", "TypeError", "ValueError", "RuntimeError",
    "MemoryError", "ImportError", "KeyError", "IndexError", "OSError",
    "ConnectionError", "TimeoutError", "JSONDecodeError", "OperationalError",
    "DatabaseError", "ProviderException", "Exception", "ZeroDivisionError",
}
CORE_EVENTS = {
    "CVideoPlayer::CloseFile()": "player_closed",
    "VideoPlayer: OnExit()": "player_exited",
    "thread end: CVideoPlayerAudio::OnExit()": "audio_thread_exited",
    "thread end: video_thread": "video_thread_exited",
    "DXVA::CDecoder::Close: closing decoder.": "hardware_decoder_closed",
    "CVideoPlayer::OpenFile:": "player_opened",
    "script has left several classes in memory": "python_cleanup_warning",
    "database is locked": "database_locked",
    "[PLAYER] monitor: exiting": "monitor_exited",
    "[PLAYER] playback did not start within": "playback_start_timeout",
}
FRAME = re.compile(
    r'File "[^"\n]*[\\/]plugin\.video\.personalstream[\\/]'
    r'((?:lib[\\/][A-Za-z0-9_./\\-]+\.py)|jacktook\.py|service\.py)", '
    r'line (\d+), in ([A-Za-z0-9_<>]+)'
)


def collect_diagnostics(log_path, since=0):
    events, frames = [], []
    with Path(log_path).open("rb") as log:
        log.seek(0, 2)
        log.seek(max(0, log.tell() - MAX_LOG_BYTES))
        lines = log.read(MAX_LOG_BYTES).decode("utf-8", errors="replace").splitlines()
    flux_traceback = False
    active = since == 0
    for line in lines:
        timestamp = re.match(r"^(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d)", line)
        if timestamp:
            active = datetime.strptime(timestamp[1], "%Y-%m-%d %H:%M:%S").timestamp() >= since
        if not active:
            continue
        for marker, event in CORE_EVENTS.items():
            if marker in line:
                events.append(event)
        if "Traceback (most recent call last)" in line:
            flux_traceback = False
        frame = FRAME.search(line)
        if frame:
            path, number, function = frame.groups()
            path = path.replace("\\", "/")
            if ".." not in path and len(path) <= 128 and len(function) <= 64:
                frames.append({"file": path, "line": int(number), "function": function})
                flux_traceback = True
        error = re.match(r"\s*([A-Za-z]+(?:Error|Exception)):", line)
        if error and flux_traceback:
            events.append("python_error:" + (error[1] if error[1] in ERROR_TYPES else "Exception"))
            flux_traceback = False
    return {"events": events[-40:], "frames": frames[-20:]}


def valid_report(report):
    fields = {"schema", "reason", "report_id", "started_at", "detected_at", "addon_version", "kodi_version", "platform", "events", "frames"}
    if set(report) != fields or type(report.get("schema")) is not int or report["schema"] != 1 or report.get("reason") != "unclean_shutdown":
        return False
    if not isinstance(report.get("report_id"), str) or not re.fullmatch(r"[a-f0-9-]{36}", report["report_id"]):
        return False
    if type(report.get("started_at")) is not int or report["started_at"] <= 0:
        return False
    if type(report.get("detected_at")) is not int or report["detected_at"] < report["started_at"]:
        return False
    for key in ("addon_version", "kodi_version"):
        if not isinstance(report.get(key), str) or not re.fullmatch(r"\d{1,3}\.\d{1,3}(?:\.\d{1,3})?", report[key]):
            return False
    if report.get("platform") not in {"Windows", "macOS", "Linux", "Android", "Other"}:
        return False
    events, frames = report.get("events"), report.get("frames")
    allowed = set(CORE_EVENTS.values()) | {"python_error:" + name for name in ERROR_TYPES}
    if not isinstance(events, list) or len(events) > 40 or any(not isinstance(e, str) or e not in allowed for e in events):
        return False
    if not isinstance(frames, list) or len(frames) > 20:
        return False
    for frame in frames:
        if not isinstance(frame, dict) or set(frame) != {"file", "line", "function"}:
            return False
        file, function = frame.get("file"), frame.get("function")
        if not isinstance(file, str) or len(file) > 128 or ".." in file or not re.fullmatch(r"(?:lib/[A-Za-z0-9_./-]+\.py|jacktook\.py|service\.py)", file):
            return False
        if type(frame.get("line")) is not int or not 1 <= frame["line"] <= 100000:
            return False
        if not isinstance(function, str) or not re.fullmatch(r"[A-Za-z0-9_<>]{1,64}", function):
            return False
    return True


def _read(path):
    try:
        if path.stat().st_size <= 16384:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except (OSError, ValueError):
        pass
    return {}


def _write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(data), encoding="utf-8")
    temporary.replace(path)


def _remove(path):
    try:
        path.unlink()
    except FileNotFoundError:
        pass


class CrashReporter:
    def __init__(self, profile, endpoint, version, kodi_version, platform, enabled, post=None):
        self.marker = Path(profile) / "reporting_session.json"
        self.pending = Path(profile) / "pending_crash_report.json"
        self.state = Path(profile) / "reporting_state.json"
        self.endpoint, self.enabled, self.post = endpoint, enabled, post
        self.session = {"id": str(uuid4()), "started_at": int(time()),
                        "addon_version": version, "kodi_version": kodi_version,
                        "platform": platform, "enabled": bool(enabled())}

    def start(self, previous_log):
        previous = _read(self.marker)
        self.session["enabled"] = bool(self.enabled())
        _write(self.marker, self.session)
        if not self.session["enabled"]:
            _remove(self.pending)
            return
        if type(previous.get("started_at")) is not int:
            return
        age = time() - previous["started_at"]
        if previous.get("enabled") is True and age >= 0 and not self.pending.exists():
            try:
                diagnostics = collect_diagnostics(previous_log, since=previous["started_at"])
            except OSError:
                diagnostics = {"events": [], "frames": []}
            report = {"schema": 1, "reason": "unclean_shutdown",
                                  "report_id": previous.get("id"),
                                  "started_at": previous["started_at"],
                                  "detected_at": int(time()),
                                  "addon_version": previous.get("addon_version"),
                                  "kodi_version": previous.get("kodi_version"),
                                  "platform": previous.get("platform"), **diagnostics}
            if valid_report(report):
                _write(self.pending, report)

    def settings_changed(self):
        enabled = bool(self.enabled())
        if not enabled:
            _remove(self.pending)
        if self.session["enabled"] != enabled:
            self.session.update(enabled=enabled, started_at=int(time()))
            _write(self.marker, self.session)

    def send_pending(self):
        if not self.enabled():
            _remove(self.pending)
            return False
        report = _read(self.pending)
        if not report:
            return False
        if not valid_report(report):
            _remove(self.pending)
            return False
        if not 0 <= time() - report["detected_at"] < MAX_AGE_SECONDS:
            _remove(self.pending)
            return False
        sent_at = _read(self.state).get("sent_at", 0)
        if type(sent_at) is not int:
            sent_at = 0
        if time() - sent_at < SEND_INTERVAL_SECONDS:
            return False
        if not self.endpoint.startswith("https://"):
            return False
        if self.post is None:
            import requests
            self.post = requests.post
        # Read the preference again immediately before the only outbound request.
        if not self.enabled():
            _remove(self.pending)
            return False
        response = self.post(self.endpoint, json=report, timeout=(3, 10), allow_redirects=False)
        if response.status_code in (200, 201, 202):
            _write(self.state, {"sent_at": int(time())})
            _remove(self.pending)
            return True
        return False

    def finish(self):
        # An older service finishing during an update must not clear its replacement's marker.
        if _read(self.marker).get("id") == self.session["id"]:
            _remove(self.marker)
