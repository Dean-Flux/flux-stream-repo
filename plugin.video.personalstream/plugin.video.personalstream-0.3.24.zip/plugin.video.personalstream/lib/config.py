"""Supported integrations for the Flux Stream foundation."""

# Personal receiver only; no GitHub credentials are distributed in the Kodi package.
CRASH_REPORT_ENDPOINT = "https://flux-stream-reports.vercel.app/api/report"

# Hidden upstream settings must not reactivate integrations through a restored profile.
FIXED_SETTINGS = {
    "external_scraper_enabled": "true",
    "external_scraper_module": "script.module.cocoscrapers",
    "external_scraper_module_name": "CocoScrapers",
    "show_uncached": "false",
    "update_action": "2",
    "torrent_enable": "false",
    "alldebrid_enabled": "false",
    "premiumize_enabled": "false",
    "debrider_enabled": "false",
    "easydebrid_enabled": "false",
    "offcloud_enabled": "false",
    "easynews_enabled": "false",
    "stremio_enabled": "false",
    "stremio_only_catalogs": "false",
    "nuvio_enabled": "false",
    "jackett_enabled": "false",
    "prowlarr_enabled": "false",
    "jacktookburst_enabled": "false",
    "jackgram_enabled": "false",
    "simkl_enabled": "false",
    "yamtrack_enabled": "false",
}

# Public application identity for the owner's Flux Stream development app.
TRAKT_CLIENT_ID = "eNa8zl7FtGB7GKzAyc_xNwLuBSS7skSCBg8bctDSewE"

# Shared metadata application key, bundled with the owner's approval.
TMDB_API_KEY = "61b84fcc4772e1f89c1270b3a1fa6d57"
