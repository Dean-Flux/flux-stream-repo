"""One short-lived watched-show snapshot shared by Kodi's plugin interpreters."""

import json
import os
import sqlite3
from contextlib import closing
from hashlib import sha256
from time import time

from lib.api.trakt.base_cache import databases_path
from lib.utils.kodi.settings import trakt_client
from lib.utils.kodi.utils import get_property

SNAPSHOT_PATH = os.path.join(databases_path, "watched_snapshot.db")
TTL_SECONDS = 120


def _account_key():
    token = get_property("trakt_token")
    if not isinstance(token, str) or not token:
        return None
    return sha256((str(trakt_client()) + "|" + token).encode("utf-8")).hexdigest()


def _connect():
    os.makedirs(os.path.dirname(SNAPSHOT_PATH), exist_ok=True)
    con = sqlite3.connect(SNAPSHOT_PATH, timeout=20, isolation_level=None)
    con.execute("CREATE TABLE IF NOT EXISTS snapshot (account TEXT PRIMARY KEY, data TEXT, expires REAL)")
    return con


def _read(con, account):
    row = con.execute("SELECT data FROM snapshot WHERE account=? AND expires>?", (account, time())).fetchone()
    if row:
        try:
            result = json.loads(row[0])
            if isinstance(result, list):
                return result
        except (ValueError, TypeError):
            pass
    return None


def get_watched_snapshot(fetch, refresh=False):
    account = _account_key()
    if account is None:
        return fetch()
    with closing(_connect()) as con:
        cached = None if refresh else _read(con, account)
        if cached is not None:
            return cached
        # Only this tiny database is locked during fetch; other Kodi caches remain usable.
        con.execute("BEGIN IMMEDIATE")
        with con:
            cached = None if refresh else _read(con, account)
            if cached is not None:
                return cached
            data = fetch()
            con.execute("DELETE FROM snapshot WHERE expires<=?", (time(),))
            con.execute("INSERT OR REPLACE INTO snapshot VALUES (?, ?, ?)",
                        (account, json.dumps(data), time() + TTL_SECONDS))
            return data


def invalidate_watched_snapshot():
    account = _account_key()
    if account is not None:
        with closing(_connect()) as con:
            con.execute("DELETE FROM snapshot WHERE account=?", (account,))
