from lib.services.background_service import JacktookMOnitor
from lib.services.crash_reporting import CrashReporter
from lib.utils.kodi.utils import ADDON_PROFILE_PATH, ADDON_VERSION, get_setting_fresh, kodilog
from lib.config import CRASH_REPORT_ENDPOINT
import re
import sys
import xbmc
from xbmcvfs import translatePath


def run():
    build = re.match(r"\d+\.\d+(?:\.\d+)?", xbmc.getInfoLabel("System.BuildVersion"))
    platform = "Android" if xbmc.getCondVisibility("System.Platform.Android") else {
        "win32": "Windows", "darwin": "macOS", "linux": "Linux"
    }.get(sys.platform, "Other")
    reporter = CrashReporter(ADDON_PROFILE_PATH, CRASH_REPORT_ENDPOINT, ADDON_VERSION,
                             build[0] if build else "0.0", platform,
                             lambda: get_setting_fresh("crash_reporting_enabled", True))
    try:
        try:
            reporter.start(translatePath("special://logpath/kodi.old.log"))
        except Exception:
            kodilog("Crash reporting could not initialize; continuing normal startup")
        monitor = JacktookMOnitor()
        monitor.crash_reporter = reporter
        if not monitor.waitForAbort(15):
            try:
                reporter.send_pending()
            except Exception:
                kodilog("Crash report remains queued; will retry on a future launch")
            monitor.waitForAbort()
    finally:
        try:
            reporter.finish()
        except OSError:
            pass


if __name__ == "__main__":
    run()
