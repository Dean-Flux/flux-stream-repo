import xbmc, xbmcgui
from contextlib import closing
from time import monotonic
from modules.OMDb import OMDbAPI
import json

logger = xbmc.log
empty_ratings = {
    "metascore": "",
    "tomatoMeter": "",
    "tomatoUserMeter": "",
    "tomatoImage": "",
    "imdbRating": "",
    "tmdbRating": "",
}


class RatingsService(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.omdb_api = OMDbAPI
        self.window = xbmcgui.Window
        self.get_window_id = xbmcgui.getCurrentWindowId
        self.get_infolabel = xbmc.getInfoLabel
        self.get_visibility = xbmc.getCondVisibility
        self.retry_id = None
        self.retry_at = 0

    def onNotification(self, sender, method, data):
        if sender == "xbmc":
            if method in ("GUI.OnScreensaverActivated", "System.OnSleep"):
                self.window(self.get_window_id()).setProperty("pause_services", "true")
                logger("###Flux Stream: Device is Asleep, PAUSING Ratings Service", 1)
            elif method in ("GUI.OnScreensaverDeactivated", "System.OnWake"):
                self.window(self.get_window_id()).clearProperty("pause_services")
                logger("###Flux Stream: Device is Awake, RESUMING Ratings Service", 1)

    def listitem_monitor(self):
        while not self.abortRequested():
            if (
                self.window(self.get_window_id()).getProperty("pause_services")
                == "true"
            ):
                self.waitForAbort(2)
                continue
            if xbmc.getSkinDir() != "skin.fluxstream":
                self.waitForAbort(15)
                continue
            api_key = self.get_infolabel("Skin.String(omdb_api_key)")
            if not api_key:
                self.waitForAbort(10)
                continue
            if not self.get_visibility(
                "Window.IsVisible(videos) | Window.IsVisible(home) | Window.IsVisible(11121)"
            ):
                self.waitForAbort(2)
                continue
            if self.get_visibility("Container.Scrolling"):
                self.waitForAbort(0.2)
                continue
            imdb_id = self.get_infolabel("ListItem.IMDBNumber")
            tmdb_rating = self.get_infolabel("ListItem.Rating")
            set_property = self.window(self.get_window_id()).setProperty
            get_property = self.window(self.get_window_id()).getProperty
            cached_ratings = get_property(f"fluxstream.cachedRatings.{imdb_id}")
            if not imdb_id or not imdb_id.startswith("tt"):
                for k, v in empty_ratings.items():
                    set_property("fluxstream.%s" % k, v)
                self.waitForAbort(0.2)
                continue
            if cached_ratings:
                result = json.loads(cached_ratings)
                for k, v in result.items():
                    set_property("fluxstream.%s" % k, v)
                self.waitForAbort(0.2)
                continue
            if imdb_id != self.retry_id or monotonic() >= self.retry_at:
                self.set_ratings(api_key, imdb_id, tmdb_rating)
            self.waitForAbort(0.2)

    def set_ratings(self, api_key, imdb_id, tmdb_rating):
        window_id = self.get_window_id()
        self.retry_id, self.retry_at = imdb_id, monotonic() + 60
        try:
            with closing(self.omdb_api()) as api:
                result = api.fetch_info({"imdb_id": imdb_id}, api_key, tmdb_rating)
        except Exception:
            logger("###Flux Stream: Ratings unavailable; retrying later", 2)
            return
        if self.abortRequested() or self.get_window_id() != window_id:
            return
        set_property = self.window(window_id).setProperty
        if result:
            set_property(f"fluxstream.cachedRatings.{imdb_id}", json.dumps(result))
            if self.get_infolabel("ListItem.IMDBNumber") == imdb_id:
                for k, v in result.items():
                    set_property("fluxstream.%s" % k, v)


if __name__ == "__main__":
    logger("###Flux Stream: Ratings Service Started", 1)
    RatingsService().listitem_monitor()
    logger("###Flux Stream: RatingsService Finished", 1)
