"""Apply the family layout once, without copying anyone's account data."""

import json
import os
import sqlite3

import xbmc
import xbmcaddon
import xbmcvfs


def seed_paths(database_path, rows):
    with sqlite3.connect(database_path) as connection:
        connection.execute("CREATE TABLE IF NOT EXISTS custom_paths (cpath_setting text unique, cpath_path text, cpath_header text, cpath_type text, cpath_label text)")
        if connection.execute("SELECT COUNT(*) FROM custom_paths").fetchone()[0] == 0:
            connection.executemany("INSERT INTO custom_paths VALUES (?, ?, ?, ?, ?)", rows)


def initialize():
    if xbmc.getSkinDir() != "skin.fluxstream":
        return
    addon = xbmcaddon.Addon("script.fluxstream.helper")
    profile = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
    os.makedirs(profile, exist_ok=True)
    with open(os.path.join(addon.getAddonInfo("path"), "resources", "defaults.json"), encoding="utf-8") as stream:
        defaults = json.load(stream)
    seed_paths(os.path.join(profile, "cpath_cache.db"), defaults["paths"])
    for setting in defaults["settings"]:
        key, value = setting["id"], setting["value"]
        if setting["type"] == "bool":
            command = "Skin.SetBool" if value == "true" else "Skin.Reset"
            xbmc.executebuiltin("{}({})".format(command, key))
        elif value:
            xbmc.executebuiltin('Skin.SetString({},"{}")'.format(key, value.replace('"', '')))
    xbmc.executebuiltin("Skin.SetBool(firsttimerun)")
    xbmc.executebuiltin("Skin.SetBool(flux_initialized)")
    xbmc.executebuiltin("ReloadSkin()")
