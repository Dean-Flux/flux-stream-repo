"""Open the two-row family search using safely encoded query properties."""

from urllib.parse import quote

import xbmc
import xbmcgui


def search(query=None):
    if query is None:
        keyboard = xbmc.Keyboard("", "Search movies and TV shows", False)
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return
        query = keyboard.getText()
    query = query.strip()
    if not query:
        return
    window = xbmcgui.Window(10000)
    window.setProperty("flux.search.title", query)
    window.setProperty("flux.search.query", quote(query, safe=""))
    xbmc.executebuiltin("ActivateWindow(1121)")
    xbmc.executebuiltin("SetFocus(27011)")
