# Flux Stream Skin for Kodi Nexus

Flux Stream is a modded version of the default Estuary skin and FENTastic, specifically designed for Umbrella users. It includes several new features and adjustments to pre-existing views, a new UI, viewtypes, customizable widgets, and a new default colors theme.
